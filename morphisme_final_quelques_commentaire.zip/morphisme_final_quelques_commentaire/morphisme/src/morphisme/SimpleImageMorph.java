package morphisme;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

/**
 * La classe SimpleImageMorph réalise le morphing entre deux forme simples unies à partir de deux ensembles de points de contrôle en générant une série d'images intermédiaires.
 */
public class SimpleImageMorph extends ImageMorph{

    /**
     * Constructeur pour initialiser un SimpleImageMorph.
     * 
     * @param pointsDebut Liste des points de départ.
     * @param pointsFin Liste des points de fin.
     * @param nbrEtapes Nombre d'images intermediaires à générer.
     * @param nomImgDebut Chemin du fichier de l'image de départ.
     * @throws IOException Si une erreur survient lors de la lecture des fichiers d'image.
     */
    public SimpleImageMorph(ArrayList<Point> pointsDebut, ArrayList<Point> pointsFin, int nbrEtapes, String nomImg) throws IOException{
        super(pointsDebut, pointsFin, nbrEtapes, nomImg);
    }

    /**
     * Effectue le morphing des images avec le nombre d'étapes spécifié.
     *
     * @return Un tableau d'images représentant chaque étape du morphing.
     * @throws IOException Si une erreur d'entrée/sortie se produit.
     */
    public BufferedImage[] morphing() throws IOException{
        BufferedImage[] res = new BufferedImage[nbrEtapes+1];


        int width = originalImage.getWidth();
        int height = originalImage.getHeight();

        // Obtenir la couleur de la forme
        Color couleurForme = getCouleurForme();

        // Obtenir la couleur du fond
        Color couleurFond = getCouleurFond();
        Color colorTmp = trouveCouleur(couleurForme,couleurFond);
        // création et enregistrement des images 
        for (int i=0; i <= nbrEtapes; i++){

            double alpha = i / (double) nbrEtapes;

            BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            ArrayList<Point> pointsInter = this.interpollation(alpha);
            dessinContour(image,pointsInter, colorTmp, couleurForme);
            rempliForme(image, colorTmp, couleurFond, couleurForme);
            res[i]=image;
        }
        return res;
    }

    
    /**
     * Dessine le contour de la forme sur l'image donnée avec les points intermédiaires et les couleurs spécifiées.
     *
     * @param img L'image sur laquelle dessiner.
     * @param points Les points intermédiaires de la forme.
     * @param color1 La première couleur utilisée pour remplir l'image.
     * @param color2 La couleur du contour de la forme.
     */
    public void dessinContour(BufferedImage img, ArrayList<Point> points, Color color1, Color color2){

        Graphics2D g2d = img.createGraphics();

        // On rempli l'image
        for(int i=0;i<img.getWidth();i++){
            for(int j=0;j<img.getHeight();j++){
                img.setRGB(i, j, color1.getRGB());
            }
        }

        // On dessine la forme en reliant les points
        for(int i=0;i<nbrPoints-1;i++){
            g2d.setColor(color2);
            g2d.drawLine((int) points.get(i).getX(), (int) points.get(i).getY(), (int) points.get(i+1).getX(), (int) points.get(i+1).getY());
        }
        g2d.drawLine((int) points.get(nbrPoints-1).getX(), (int) points.get(nbrPoints-1).getY(), (int) points.get(0).getX(), (int) points.get(0).getY());
    }
}