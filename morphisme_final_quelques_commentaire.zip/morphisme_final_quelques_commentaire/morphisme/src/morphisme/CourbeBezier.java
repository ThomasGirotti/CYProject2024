package morphisme;

import java.util.ArrayList;

/**
 * La classe CourbeBezier représente une courbe de Bézier cubique définie par quatre points de contrôle.
 */
public class CourbeBezier {

    //contient 4 points: depart, controle1, controle2, fin
    private Point[] tab;
    

    /**
     * Constructeur pour initialiser la courbe de Bézier avec les points de contrôle donnés.
     *
     * @param depart Le point de départ de la courbe.
     * @param ctrl1 Le premier point de contrôle de la courbe.
     * @param ctrl2 Le deuxième point de contrôle de la courbe.
     * @param fin Le point de fin de la courbe.
     */
    public CourbeBezier(Point depart, Point ctrl1, Point ctrl2, Point fin){
        tab = new Point[4];
        tab[0]=depart;
        tab[1]=ctrl1;
        tab[2]=ctrl2;
        tab[3]=fin;
    }
    

    /**
     * Retourne le tableau des points de contrôle.
     * 
     * @return Tableau des points de contrôle.
     */
    public Point[] getTab(){
        return tab;
    }


    /**
     * Génère les points de la courbe de Bézier.
     * 
     * @param nbr Nombre de points à générer sur la courbe.
     * @return Liste des points de la courbe.
     */
    public ArrayList<Point> courbe(int nbr){
        ArrayList<Point> pointsCourbe = new ArrayList<>();
        
        // Calcule chaque point sur la courbe de Bézier et les ajoutes dans la liste
        for (int i = 0; i <= nbr; i++) {
            double t = (double) i / nbr;
            Point pointCourant = calculerPointCourbe(t);
            pointsCourbe.add(pointCourant);
        }
        
        return pointsCourbe;
    }


    /**
     * Calcule un point de la courbe de Bézier pour une valeur donnée de t.
     * 
     * @param t Valeur du paramètre t entre 0 et 1.
     * @return Le point de la courbe pour le t donné.
     */
    private Point calculerPointCourbe(double t) {
        double x = 0;
        double y = 0;
        Point[] points = this.getTab();

        double coef = 1 - t;

        // Formule de courbe de Bézier cubique
        // P(t) = (1-t)^3 * P0 + 3 * (1-t)^2 * t * P1 + 3 * (1-t) * t^2 * P2 + t^3 * P3
        x += Math.pow(coef, 3) * points[0].getX();
        y += Math.pow(coef, 3) * points[0].getY();

        x += 3 * Math.pow(coef, 2) * t * points[1].getX();
        y += 3 * Math.pow(coef, 2) * t * points[1].getY();

        x += 3 * coef * Math.pow(t, 2) * points[2].getX();
        y += 3 * coef * Math.pow(t, 2) * points[2].getY();

        x += Math.pow(t, 3) * points[3].getX();
        y += Math.pow(t, 3) * points[3].getY();

        return new Point((int) x, (int) y);
    }


}