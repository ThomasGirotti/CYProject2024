package morphisme;

import java.util.ArrayList;
import java.util.Stack;
import javax.imageio.IIOException;
import javax.imageio.ImageIO;
import javax.imageio.stream.FileImageOutputStream;
import javax.imageio.stream.ImageOutputStream;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * La classe abstraite ImageMorph fournit la structure de base pour effectuer le morphing d'images entre deux ensembles de points de contrôle.
 * Les sous-classes doivent implémenter des méthodes spécifiques pour réaliser le morphing.
 */
public abstract class ImageMorph {

    protected ArrayList<Point> pointsDebut;
    protected ArrayList<Point> pointsFin;
    protected int nbrEtapes;
    protected int nbrPoints;
    protected BufferedImage originalImage;


    /**
     * Constructeur pour initialiser un ImageMorph.
     * 
     * @param pointsDebut Liste des points de départ.
     * @param pointsFin Liste des points de fin.
     * @param nbrEtapes Nombre d'images intermediaires à générer.
     * @param nomImgDebut Chemin du fichier de l'image de départ.
     * @throws IOException Si une erreur survient lors de la lecture des fichiers d'image.
     */
    public ImageMorph(ArrayList<Point> pointsDebut, ArrayList<Point> pointsFin, int nbrEtapes, String nomImg) throws IOException{
        this.nbrEtapes=nbrEtapes;
        this.pointsDebut=pointsDebut;
        this.pointsFin=pointsFin;
        // Charge l'image de départ
        File inputFile = new File(nomImg);
        this.originalImage = ImageIO.read(inputFile);
        // récuperation du nombre de points de controles
        this.nbrPoints = pointsDebut.size();
    }


    /**
     * Obtient les deux principales couleurs de l'image : une couleur centrale et une couleur de coin.
     * 
     * @return Un tableau de deux couleurs principales.
     */
    private Color[] getTwoMainColors() {
        Color centerColor = new Color(originalImage.getRGB(originalImage.getWidth() / 2, originalImage.getHeight() / 2));
        Color cornerColor = new Color(originalImage.getRGB(0, 0));
        return new Color[] { centerColor, cornerColor };
    }


    /**
     * Obtient la couleur de la forme de l'image.
     * 
     * @return La couleur de la forme.
     */
    public Color getCouleurForme() {
        Color[] mainColors = getTwoMainColors();
        return mainColors[0];
    }


    /**
     * Obtient la couleur du fond de l'image.
     * 
     * @return La couleur du fond.
     */
    public Color getCouleurFond() {
        Color[] mainColors = getTwoMainColors();
        return mainColors[1];
    }


    /**
     * Calcule l'interpolation des points entre les deux listes de points en fonction du facteur alpha.
     * 
     * @param alpha Le facteur d'interpolation entre 0 et 1.
     * @return Une liste de points interpolés.
     */
    public ArrayList<Point> interpollation(double alpha){
        // création du tableau des points intermédiaires
        ArrayList<Point> res = new ArrayList<>();
        // on rempli le tableau
        for(int i=0;i<nbrPoints;i++){
            int x = (int) (pointsDebut.get(i).getX() * (1 - alpha) + pointsFin.get(i).getX() * alpha);
            int y = (int) (pointsDebut.get(i).getY() * (1 - alpha) + pointsFin.get(i).getY() * alpha);
            Point a = new Point(x,y);
            res.add(a);
        }
        // retourne le tableau des points intermédiaires
        return res;
    }


    /**
     * Remplit une forme dessinée dans l'image avec la couleur intérieure spécifiée.
     * 
     * @param img L'image à modifier.
     * @param fondActuel La couleur temporaire du fond.
     * @param fondFinal La couleur finale du fond.
     * @param interieur La couleur intérieure pour remplir la forme.
     */
    protected void rempliForme(BufferedImage img, Color fondActuel, Color fondFinal, Color interieur){
        // On stocke la valeur RGB de la couleur intérieure
        int interieurRGB = interieur.getRGB();
        // On cherche un point extérieur de la forme dessinée
        Point start = pointExt(img, fondActuel);
        
        // Vérifier si le point extérieur trouvé est en dehors de l'image
        if(start.getX() >= img.getWidth() || start.getY() >= img.getHeight()){

            // Si le point extérieur est en dehors de l'image, la forme prend toute l'image donc on la rempli avec la couleur intérieure
            for(int i=0;i<img.getWidth();i++){
                for(int j=0;j<img.getHeight();j++){
                    img.setRGB(i, j, interieurRGB);
                }
            }
        }else{

            // Si un point extérieur à été trouvéde, on utilise une méthode de diffusion pour colorier le fond de la bonne couleur
            diffusion(img, start, fondActuel, fondFinal);

            // Obtenir la valeur RGB de la couleur de fond actuelle
            int fondActuelRGB = fondActuel.getRGB();


           // diffusion(img,,fondActuel, interieur);
            // Parcourir l'image et remplacer les pixels de la couleur de fond actuelle par la couleur intérieure
            for(int i=0;i<img.getWidth();i++){
                for(int j=0;j<img.getHeight();j++){
                    if(img.getRGB(i, j)==fondActuelRGB){
                        img.setRGB(i, j, interieurRGB);
                    }
                }
            }
        }
        
    }


    /**
     * Trouve un point extérieur à la forme dessinée dans l'image.
     * 
     * @param img L'image à analyser.
     * @param couleurFond La couleur de fond.
     * @return Un point extérieur à la forme ou un point qui n'est pas dans l'image si la forme prend toute l'image.
     */
    protected Point pointExt(BufferedImage img, Color couleurFond){
        int width = img.getWidth();
        int height = img.getHeight();
        int couleurFondRGB = couleurFond.getRGB();

        // Parcour les pixels des bords supérieur et inférieur de l'image
        for(int i=0; i<width; i++){
            // Vérifie le pixel au bord supérieur
            if(img.getRGB(i, 0)==couleurFondRGB){
                return new Point(i, 0);
            }
            // Vérifie le pixel au bord inférieur
            if(img.getRGB(i, height-1)==couleurFondRGB){
                return new Point(i, height-1);
            }
        }

        // Parcour les pixels des bords gauche et droit de l'image
        for(int j=0; j<height; j++){
            // Vérifie le pixel au bord gauche
            if(img.getRGB(0, j)==couleurFondRGB){
                return new Point(0, j);
            }
            // Vérifie le pixel au bord droit
            if(img.getRGB(width-1, j)==couleurFondRGB){
                return new Point(width-1, j);
            }
        }
        // Si aucune couleur de fond n'est trouvée sur les bords, on retourne un point en dehors de l'image
        return new Point(width,height);
    }



    /**
     * Diffuse une couleur dans une image à partir d'un point initial en utilisant une méthode de remplissage par propagation.
     * 
     * @param img L'image à modifier.
     * @param point Le point initial pour commencer la diffusion.
     * @param color1 La couleur à remplacer.
     * @param color2 La couleur de remplacement.
     */
    protected void diffusion(BufferedImage img, Point point, Color color1, Color color2){
        int width = img.getWidth();
        int height = img.getHeight();
        // Crée une pile pour stocker les pixels à explorer
        Stack<Point> stack = new Stack<>();
        stack.push(new Point((int) point.getX(), (int) point.getY()));
        // Parcours de la pile
        while (!stack.isEmpty()) {
            Point current = stack.pop();
            int x = (int) current.getX();
            int y = (int) current.getY();
            // Vérifie si le pixel actuel est de la couleur cible
            if (img.getRGB(x, y) == color1.getRGB()) {
                img.setRGB(x, y, color2.getRGB()); // Remplace la couleur
                // Ajoute les pixels voisins à la pile s'ils sont dans les limites de l'image
                if (x - 1 >= 0) stack.push(new Point(x - 1, y));
                if (x + 1 < width) stack.push(new Point(x + 1, y));
                if (y - 1 >= 0) stack.push(new Point(x, y - 1));
                if (y + 1 < height) stack.push(new Point(x, y + 1));
            }
        }
    }


    /**
     * Trouve une couleur qui est différente de deux couleurs données.
     * 
     * @param color1 La première couleur.
     * @param color2 La deuxième couleur.
     * @return Une couleur différente des deux couleurs d'entrée.
     */
    protected Color trouveCouleur(Color color1, Color color2){
        Color res = new Color(0);
        if((color1.getRGB()!=res.getRGB()) && (color2.getRGB()!=res.getRGB())){
            return res;
        }else {
            res = new Color(1);
            if((color1.getRGB()!=res.getRGB()) && (color2.getRGB()!=res.getRGB())){
                return res;
            }else {
                res = new Color(2);
            }
        }
        return res;
    }


    /**
     * Crée un GIF à partir d'un tableau d'images.
     * 
     * @param images Le tableau contenant les images à inclure dans le GIF.
     * @param gifSpeed 
     * @throws IIOException Si une erreur survient lors de l'écriture du fichier GIF.
     * @throws IOException Si une erreur survient lors de l'ouverture du fichier GIF.
     */
    public void creerGif(BufferedImage[] images, int gifSpeed) throws IIOException, IOException{
        File fichierGif = new File("morph.gif");
        ImageOutputStream output = new FileImageOutputStream(fichierGif);
        GifSequenceWriter gifWriter = new GifSequenceWriter(output, BufferedImage.TYPE_INT_ARGB, 20, true);
        for (int i = 0; i < gifSpeed; i++){
            gifWriter.writeToSequence(images[i]);
        }
        gifWriter.close();
        output.close();
    }
}