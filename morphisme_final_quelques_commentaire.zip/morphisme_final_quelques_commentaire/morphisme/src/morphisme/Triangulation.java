package morphisme;

import java.util.ArrayList;

public class Triangulation {
    ArrayList<Triangle> tab;

    public Triangulation (ArrayList<Triangle> t){
        this.tab = t;
    }

    public ArrayList<Triangle> getTriangles(){
        return this.tab;
    }

    public ArrayList<Triangle> aRelier(Point p){
        ArrayList<Triangle> tmp = new ArrayList<Triangle>();
        
        //ajoute la liste des triangles concernés.
        //Attention il peut y avoir des doublons de points
        for (Triangle i : this.getTriangles()){
            if (p.distance(i.getCercle().getCentre()) < i.getCercle().getRayon()){
                tmp.add(i);
            }
        }
        
        return tmp;
    }

    public void triangulation(Point p){
        ArrayList<Triangle> aTester = this.aRelier(p);
        ArrayList<Triangle> appartenance = this.aRelier(p);

        ArrayList<Droite> tabDroite = new ArrayList<Droite>();
        ArrayList<Droite> suppDroite = new ArrayList<Droite>();
        ArrayList<Triangle> suppr = new ArrayList<Triangle>();
        ArrayList<Triangle> tmp = new ArrayList<Triangle>();
        ArrayList<Triangle> tmpSuppr = new ArrayList<Triangle>();

        for (Triangle i : aTester){
            tabDroite.add(new Droite(i.getPoint1(),i.getPoint2()));
            tabDroite.add(new Droite(i.getPoint2(),i.getPoint3()));
            tabDroite.add(new Droite(i.getPoint1(),i.getPoint3()));
            tabDroite.add(new Droite(i.getPoint1(),p));
            tabDroite.add(new Droite(i.getPoint2(),p));
            tabDroite.add(new Droite(i.getPoint3(),p));
            tmp.add(new Triangle(i.getPoint1(), i.getPoint2(), p));
            tmp.add(new Triangle(i.getPoint1(), p, i.getPoint3()));
            tmp.add(new Triangle(p, i.getPoint2(), i.getPoint3()));
        }

        //supprime les doublons de tabDroite
        for (int i = 0 ; i< tabDroite.size();i++){
            for (int j = i+1 ; j<tabDroite.size() ;j++){
                if (tabDroite.get(i).memeDroite(tabDroite.get(j))){
                    
                    suppDroite.add(tabDroite.get(i));
                }
            }
        }
        

        for (Droite i : suppDroite){
            tabDroite.remove(i);
        }

        //elimine les droites qui se coupent
        for (int i= 0; i< tabDroite.size();i++){ 
            for ( int j = i+1 ; j<tabDroite.size();j++){ 
                if ((tabDroite.get(i).intersectionDroiteDroite(tabDroite.get(j))) && ( (tabDroite.get(i).getDebut() != tabDroite.get(j).getDebut() ) &&
                    tabDroite.get(i).getDebut() != tabDroite.get(j).getFin() &&
                    tabDroite.get(i).getFin() != tabDroite.get(j).getDebut() &&
                    tabDroite.get(i).getFin() != tabDroite.get(j).getFin()) )  {
                    appartenance = tabDroite.get(j).droiteAppartient(aTester);
                    //j appartient pas aux vieux triangles
                    if (appartenance.isEmpty()){
                        tmpSuppr = tabDroite.get(i).droiteAppartient(aTester);
                        for (Triangle k : tmpSuppr){
                            suppr.add(k);
                        }
                        tmpSuppr = tabDroite.get(i).droiteAppartient(tmp);
                        for (Triangle k : tmpSuppr){
                            suppr.add(k);
                        }
                        //l'inverse
                    }else{
                        tmpSuppr = tabDroite.get(j).droiteAppartient(aTester);
                        for (Triangle k : appartenance){
                            suppr.add(k);
                        }
                        tmpSuppr = tabDroite.get(j).droiteAppartient(tmp);
                        for (Triangle k : tmpSuppr){
                            suppr.add(k);
                        }
                    }
                    
                }
            }
        }
        //ajout des nouveaux triangles
        for (Triangle i :tmp){
            this.tab.add(i);
        }
        //on supprime le vieux triangle au cas ou il ai échappé aà la vérification
        
        //suppression des triangles en trop
        for (Triangle i : suppr){
            this.tab.remove(i);
        }
        suppr.clear();
        tmp.clear();       
    }
    
}