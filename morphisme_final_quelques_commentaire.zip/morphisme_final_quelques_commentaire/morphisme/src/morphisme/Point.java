package morphisme;

/**
 * La classe Point représente un point dans un espace bidimensionnel avec des coordonnées x et y.
 * Elle peut également avoir un nom optionnel.
 */
public class Point {
	private int x;
	private int y;
	private String nom;
	public Point(int x, int y) {
		this.x = x;
        this.y = y;
	}


	/**
     * Constructeur pour créer un point avec des coordonnées x et y.
     *
     * @param x La coordonnée x du point.
     * @param y La coordonnée y du point.
     */
    public Point(int x, int y, String nom) {
		this(x, y);
		this.nom = nom;
	}


	/**
     * Retourne la coordonnée x du point.
     *
     * @return La coordonnée x.
     */
	public int getX() {
		return x;
	}


	/**
     * Modifie la coordonnée x du point.
     *
     * @param x La nouvelle coordonnée x.
     */
	public void setX(int x) {
		this.x = x;
	}


	/**
     * Retourne la coordonnée y du point.
     *
     * @return La coordonnée y.
     */
	public int getY() {
		return y;
	}


	/**
     * Modifie la coordonnée y du point.
     *
     * @param y La nouvelle coordonnée y.
     */
	public void setY(int y) {
		this.y = y;
	}


	/**
     * Retourne le nom du point.
     *
     * @return Le nom du point.
     */
    public String getNom() {
		return this.nom;
	}


	/**
     * Modifie le nom du point.
     *
     * @param nom Le nouveau nom du point.
     */
	public void setNom(String nom) {
		this.nom = nom;
	}


	/**
     * Vérifie si le point actuel est au même endroit qu'un autre point donné.
     *
     * @param p Le point à comparer.
     * @return true si les deux points ont les mêmes coordonnées, false sinon.
     */
	public boolean memeEndroit(Point p) {
		return (this.getX() == p.getX() && this.getY() == p.getY());
	}


	/**
     * Redéfinition de la méthode equals pour comparer deux points.
     *
     * @param obj L'objet à comparer.
     * @return true si les objets sont égaux, false sinon.
     */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null || getClass() != obj.getClass())
			return false;
		Point other = (Point) obj;
		return x == other.x && y == other.y;
	}


	/**
     * Retourne une représentation en chaîne de caractères du point.
     *
     * @return Une chaîne de caractères représentant le point.
     */
	@Override
	public String toString() {
		return "Point [x=" + x + ", y=" + y + "]";
	}


	/**
     * Calcule la distance euclidienne entre le point actuel et un autre point donné.
     *
     * @param p Le point avec lequel calculer la distance.
     * @return La distance entre les deux points.
     */
	public float distance(Point p){
		return(int)(Math.sqrt(Math.pow(x-p.x, 2)+Math.pow(y-p.y, 2)));
	}
}