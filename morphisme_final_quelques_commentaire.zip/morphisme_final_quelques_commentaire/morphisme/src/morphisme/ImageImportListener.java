package morphisme;

import javafx.scene.image.Image;

public interface ImageImportListener {
    void onImageImported();
    boolean verificationTaillePhoto(Image photo);
}