package morphisme;

/**
 * La classe représente un cercle défini par un centre et un rayon.
 * 
 */

public class Cercle {
    private Point centre;
    private float rayon;

    /**
     * Construit un cercle avec un centre et un rayon 
     * 
     * @param p Le centre du cercle
     * @param r Le rayon du cercle
     */
    public Cercle(Point p, float r) {
        this.centre = p;
        this.rayon = r;
    }

    /**
     * Retourne le centre du cercle
     * 
     * @return Le centre du cercle
     */
    public Point getCentre() {
        return this.centre;
    }

    /**
     * Retourne le rayon du cercle
     * 
     * @return Le rayon du cercle
     */
    public float getRayon() {
        return this.rayon;
    }

    /**
     * Vérifie si un point donné est sur le cercle
     * 
     * @param p Le point à vérifier
     * @return true si le point est sur le cercle, false sinon
     */
    public boolean contient(Point p) {
        return p.distance(this.centre) <= this.rayon;
    }
}
