package morphisme;

import java.util.ArrayList;

/**
 * Cette classe permet de représenter une droite définie par deux points
 */

public class Droite{
	private float a;
	private float b;
	private Point debut;
	private Point fin;

	
    /**
     * Constructeur de la classe Droite
     *
     * @param p1 Le premier point de la droite
     * @param p2 Le deuxième point de la droite
     */
	public Droite(Point p1, Point p2){
		this.a =  (float) ((p2.getY() - p1.getY()) / (p2.getX() - p1.getX() + 0.000001));
		this.b = p1.getY() -( this.a * p1.getX());
		this.debut = p1;
		this.fin = p2;
	}
	
    /**
     * Retourne le coefficient directeur de la droite
     *
     * @return Le coefficient directeur
     */
	public float getA() {
		return a;
	}
	
    /**
     * Définit le coefficient directeur de la droite
     *
     * @param a Le nouveau coefficient directeur
     */
	public void setA(float a) {
		this.a = a;
	}
	
	 /**
     * Retourne l'ordonnée à l'origine de la droite
     *
     * @return L'ordonnée à l'origine
     */
	public float getB() {
		return b;
	}
	
    /**
     * Définit l'ordonnée à l'origine de la droite
     *
     * @param b La nouvelle ordonnée à l'origine
     */
	public void setB(float b) {
		this.b = b;
	}
	
    /**
     * Retourne le point de début de la droite
     *
     * @return Le point de début
     */
	public Point getDebut() {
		return this.debut;
	}
	
    /**
     * Retourne le point de fin de la droite
     *
     * @return Le point de fin
     */
	public Point getFin() {
		return this.fin;
	}
	

	
    /**
     * Retourne une chaine de caractere qui represente la droite
     *
     * @return Une chaîne de caractères représentant la droite
     */
	@Override
	public String toString(){
		return this.getDebut().toString() + this.getFin().toString();
	}
	
	
    /**
     * Vérifie à quels triangles une droite appartient parmi une liste de triangles
     *
     * @param tab La liste de triangles à vérifier
     * @return Une liste de triangles auxquels la droite appartient
     */
	public ArrayList<Triangle> droiteAppartient(ArrayList<Triangle> tab){
		ArrayList<Triangle> res = new ArrayList<>();
		for (Triangle i : tab){
			if ( (this.debut.memeEndroit(i.getPoint1()) && (this.fin.memeEndroit(i.getPoint2()) || this.fin.memeEndroit(i.getPoint3() ) ) )  ||
			(this.debut.memeEndroit(i.getPoint2()) && (this.fin.memeEndroit(i.getPoint1()) || this.fin.memeEndroit(i.getPoint3() ) ) ) ||
			(this.debut.memeEndroit(i.getPoint3()) && (this.fin.memeEndroit(i.getPoint2()) || this.fin.memeEndroit(i.getPoint1() ) ) )){
				
				res.add(i);
			}
		}
		return res;
	}
	
    /**
     * Retourne la droite perpendiculaire à cette droite passant par son milieu
     *
     * @return La droite perpendiculaire
     */
	public Droite perpendiculaire() {
		int milieuX = (int) (this.debut.getX() + this.fin.getX()) / 2;
		int milieuY = (int) (this.debut.getY() + this.fin.getY()) / 2;
	
		float pentePerpendiculaire = -1 / this.getA();
	
		int chercheX;
		int chercheY;
		if (!Float.isFinite(pentePerpendiculaire)) {
			chercheX = milieuX;
			chercheY = milieuY + 1024;
			return new Droite(new Point(milieuX, milieuY - 1024), new Point(chercheX, chercheY));
		} else {
			chercheX = milieuX + 1024;
			chercheY = milieuY + (int) (pentePerpendiculaire * (chercheX - milieuX));
			int deplacementY = chercheY - milieuY;
			int deplacementX = chercheX - milieuX;
			return new Droite(new Point(milieuX - 5 * deplacementX, milieuY - 5 * deplacementY), new Point(chercheX + 5 * deplacementX, chercheY + 5 * deplacementY));
		}
	}

    /**
     * Retourne le point d'intersection de cette droite avec une autre droite
     *
     * @param d L'autre droite
     * @return Le point d'intersection
     */
	public Point intersectionDroitePoint(Droite d){

		int x = (int) ((d.getB() - this.getB()) / (this.getA() - d.getA()));
		int y = (int) ( this.getA() * x + this.getB());

		return new Point(x, y);
	}

    /**
     * Vérifie si cette droite coupe une autre droite
     *
     * @param d L'autre droite
     * @return true si les droites se coupent, false sinon
     */
	public boolean intersectionDroiteDroite(Droite d) {
		// Coordinates of this segment
		float x1 = this.getDebut().getX();
		float y1 = this.getDebut().getY();
		float x2 = this.getFin().getX();
		float y2 = this.getFin().getY();
	
		// Coordinates of segment d
		float x3 = d.getDebut().getX();
		float y3 = d.getDebut().getY();
		float x4 = d.getFin().getX();
		float y4 = d.getFin().getY();
	
		// Calculer les déterminants pour trouver le point d'intersection
		float denom = (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1);
	
		// Si denom est zéro, les droites sont parallèles
		if (denom == 0) {
			return false;
		}
	
		float ua = ((x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3)) / denom;
		float ub = ((x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3)) / denom;
	
		// Si ua et ub sont compris entre 0 et 1, les segments se coupent
		if (ua >= 0 && ua <= 1 && ub >= 0 && ub <= 1) {
			return true;
		} else {
			return false;
		}
	}	
	
    /**
     * Vérifie si deux droites sont identiques
     *
     * @param d L'autre droite à comparer
     * @return true si les droites sont identiques, false sinon
     */
	public boolean memeDroite(Droite d){
		return ( (this.getDebut().equals(d.getDebut()) && this.getFin().equals(d.getFin()) ) || (this.getDebut().equals(d.getFin()) && this.getFin().equals(d.getDebut())) );
	}
	 
	
	

    /**
     * Vérifie si un point est au-dessus de la droite
     *
     * @param p Le point à vérifier
     * @return true si le point est au-dessus de la droite, false sinon
     */
	public boolean estAuDessus(Point p) {
		if (p.getY() > this.getA() * p.getX() + this.getB()) {
			return true;
		}else {
			return false;
		}
	}
	
    /**
     * Vérifie si un point est en dessous de la droite
     *
     * @param p Le point à vérifier
     * @return true si le point est en dessous de la droite, false sinon
     */
	public boolean estEnDessous(Point p) {
		return !(estAuDessus(p));
	}
}
