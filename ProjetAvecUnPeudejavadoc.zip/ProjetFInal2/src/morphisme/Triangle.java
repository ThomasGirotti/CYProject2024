package morphisme;

import java.util.ArrayList;


/**
 * Cette classe permet de représenter un triangle par ses 3 sommets (Points), chaque sommet a un numéro et le cercle correspond
 * au cercle circonscrit
 */
public class Triangle {
    private Point p1;
    private Point p2;
    private Point p3;
    private int p1Index;
    private int p2Index;
    private int p3Index;
    private Cercle cercle;
    
    /**
     * Constructeur de la classe Triangle
     *
     * @param p1 Premier sommet du triangle
     * @param p2 Deuxième sommet du triangle
     * @param p3 Troisième sommet du triangle
     */
    public Triangle(Point p1, Point p2, Point p3) {
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        Droite d1 = new Droite(p1, p2);
        Droite d2 = new Droite(p2, p3);
        Droite per1 = d1.perpendiculaire();
        Droite per2 = d2.perpendiculaire();
        this.cercle = new Cercle(per1.intersectionDroitePoint(per2), this.p1.distance(per1.intersectionDroitePoint(per2)));
    }
    
    /**
     * Constructeur de la classe Triangle avec indices
     *
     * @param p1 Premier sommet du triangle
     * @param p2 Deuxième sommet du triangle
     * @param p3 Troisième sommet du triangle
     * @param p1Index Indice du premier sommet
     * @param p2Index Indice du deuxième sommet
     * @param p3Index Indice du troisième sommet
     */
    public Triangle(Point p1, Point p2, Point p3, int p1Index, int p2Index, int p3Index) {
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        Droite d1 = new Droite(p1, p2);
        Droite d2 = new Droite(p2, p3);
        Droite per1 = d1.perpendiculaire();
        Droite per2 = d2.perpendiculaire();
        this.cercle = new Cercle(per1.intersectionDroitePoint(per2), this.p1.distance(per1.intersectionDroitePoint(per2)));
        this.p1Index = p1Index;
        this.p2Index = p2Index;
        this.p3Index = p3Index;
    }
    
    /**
     * Retourne le cercle circonscrit du triangle
     *
     * @return Le cercle circonscrit
     */
    public Cercle getCercle() {
        return this.cercle;
    }
    
    /**
     * Retourne le premier sommet du triangle
     *
     * @return Le premier sommet
     */
    public Point getPoint1() {
        return this.p1;
    }
    
    /**
     * Retourne le deuxieme sommet du triangle
     *
     * @return Le deuxieme sommet
     */
    public Point getPoint2() {
        return this.p2;
    }
    
    /**
     * Retourne le troisieme sommet du triangle
     *
     * @return Le troisieme sommet
     */
    public Point getPoint3() {
        return this.p3;
    }
    
    /**
     * Retourne l'indice du premier sommet
     *
     * @return L'indice du premier sommet
     */
    public int getP1Index() {
        return this.p1Index;
    }
    
    /**
     * Retourne l'indice du deuxieme sommet
     *
     * @return L'indice du deuxieme sommet
     */
    public int getP2Index() {
        return this.p2Index;
    }
    
    /**
     * Retourne l'indice du troisieme sommet
     *
     * @return L'indice du troisieme sommet
     */
    public int getP3Index() {
        return this.p3Index;
    }
    
    /**
     * Définit le premier sommet du triangle
     *
     * @param p1 Le nouveau premier sommet
     */
    public void setP1(Point p1) {
        this.p1 = p1;
    }
    
    /**
     * Définit le deuxieme sommet du triangle
     *
     * @param p2 Le nouveau deuxieme sommet
     */
    public void setP2(Point p2) {
        this.p2 = p2;
    }
    
    /**
     * Définit le troisieme sommet du triangle
     *
     * @param p3 Le nouveau troisieme sommet
     */
    public void setP3(Point p3) {
        this.p3 = p3;
    }
    
    /**
     * Définit l'indice du premier sommet
     *
     * @param p1Index Le nouvel indice du premier sommet
     */
    public void setP1Index(int p1Index) {
        this.p1Index = p1Index;
    }
    
    /**
     * Définit l'indice du deuxieme sommet
     *
     * @param p2Index Le nouvel indice du deuxieme sommet
     */
    public void setP2Index(int p2Index) {
        this.p2Index = p2Index;
    }
    
    /**
     * Définit l'indice du troisieme sommet
     *
     * @param p3Index Le nouvel indice du troisieme sommet
     */
    public void setP3Index(int p3Index) {
        this.p3Index = p3Index;
    }
    
    /**
     * Définit le cercle circonscrit du triangle
     *
     * @param cercle Le nouveau cercle circonscrit
     */
    public void setCercle(Cercle cercle) {
        this.cercle = cercle;
    }
    
    /**
     * Vérifie si deux triangles sont identiques
     *
     * @param t Le triangle à comparer
     * @return true si les triangles sont identiques, false sinon
     */
    public boolean memeTriangle(Triangle t) {
        boolean res = true;
        ArrayList<Point> listeP = new ArrayList<>();
        listeP.add(this.getPoint1());
        listeP.add(this.getPoint2());
        listeP.add(this.getPoint3());
        for (Point p : listeP) {
            if (!(p.memeEndroit(t.getPoint1()) || p.memeEndroit(t.getPoint2()) || p.memeEndroit(t.getPoint3()))) {
                res = false;
            }
        }
        return res;
    }
    
    /**
     * Vérifie si le triangle contient un point donné
     *
     * @param p Le point à vérifier
     * @return true si le triangle contient le point, false sinon
     */
    public boolean contient(Point p) {
        int eq1 = ((this.p1.getX() - p.getX()) * (this.p2.getY() - p.getY())) - ((this.p1.getY() - p.getY()) * (this.p2.getX() - p.getX()));
        int eq2 = ((this.p2.getX() - p.getX()) * (this.p3.getY() - p.getY())) - ((this.p2.getY() - p.getY()) * (this.p3.getX() - p.getX()));
        int eq3 = ((this.p3.getX() - p.getX()) * (this.p1.getY() - p.getY())) - ((this.p3.getY() - p.getY()) * (this.p1.getX() - p.getX()));
        return (eq1 > 0 && eq2 > 0 && eq3 > 0) || (eq1 < 0 && eq2 < 0 && eq3 < 0);
    }
    
    /**
     * Permet de créer une chaîne de caractères représentant le triangle avec toutes ses informations
     *
     * @return Une chaîne de caractères représentant le triangle
     */
    @Override
    public String toString() {
        return "Triangle [p1=" + p1 + ", p2=" + p2 + ", p3=" + p3 + ", p1Index=" + p1Index + ", p2Index=" + p2Index + ", p3Index=" + p3Index + "]";
    }
}
