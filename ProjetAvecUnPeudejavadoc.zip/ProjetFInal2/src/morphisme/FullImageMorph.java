package morphisme;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

public class FullImageMorph extends ImageMorph{
	protected BufferedImage finalImage;
	public FullImageMorph(ArrayList<Point> pointsDebut, ArrayList<Point> pointsFin, int nbrEtapes, String nomImgEntree, String nomImgSortie) throws IOException {
		super(pointsDebut, pointsFin, nbrEtapes, nomImgEntree);
		File inputFile = new File(nomImgSortie);
        this.finalImage = ImageIO.read(inputFile);
	}

	public BufferedImage[] morphing() throws IOException {
		BufferedImage[] res = new BufferedImage[nbrEtapes+1];

		// Créer les grands triangles initiaux
		Point p1 = pointsDebut.get(0);
		Point p2 = pointsDebut.get(1);
		Point p3 = pointsDebut.get(2);
		Point p4 = pointsDebut.get(3);
		Triangle grandTriangle1 = new Triangle(p1, p2, p3);
		Triangle grandTriangle2 = new Triangle (p1,p2,p4);
		ArrayList<Triangle> trianglesContour = new ArrayList<>();
		trianglesContour.add(grandTriangle1);
		trianglesContour.add(grandTriangle2);
		Triangulation triangulation = new Triangulation(trianglesContour);

		for (int i = 4; i < pointsDebut.size(); i++) {
			triangulation.triangulation(pointsDebut.get(i));
		}
		ArrayList<Triangle> trianglesEntree = triangulation.getTriangles();

		// Dessiner les triangles sur l'image d'entrée
		BufferedImage imageAvecTriangles = dessinerTriangles(originalImage, trianglesEntree);
		ImageIO.write(imageAvecTriangles, "png", new File("image_avec_triangles.png"));

		// Ajouter les indices des sommets aux triangles de départ
		for (Triangle triangle : trianglesEntree) {
		    triangle.setP1Index(pointsDebut.indexOf(triangle.getPoint1()));
		    triangle.setP2Index(pointsDebut.indexOf(triangle.getPoint2()));
		    triangle.setP3Index(pointsDebut.indexOf(triangle.getPoint3()));
		    System.out.println("depart " + triangle.toString());
		}

		// Créer une liste de triangles pour l'image de sortie en utilisant les mêmes indices
		List<Triangle> trianglesSortie = new ArrayList<>();
		for (Triangle triangle : trianglesEntree) {
		    Point a = pointsFin.get(triangle.getP1Index());
		    Point b = pointsFin.get(triangle.getP2Index());
		    Point c = pointsFin.get(triangle.getP3Index());
		    trianglesSortie.add(new Triangle(a, b, c, triangle.getP1Index(), triangle.getP2Index(), triangle.getP3Index()));
		}

		// Liste pour stocker les images intermédiaires pour le gif
		for (int i = 0; i <= nbrEtapes; i++) {
			double alpha = i / (double) nbrEtapes;

			// Interpolation des points pour l'étape actuelle
			List<Point> pointsIntermediaires = new ArrayList<>();
			for (int j = 0; j < pointsDebut.size(); j++) {
				double x = pointsDebut.get(j).getX() * (1 - alpha) + pointsFin.get(j).getX() * alpha;
				double y = pointsDebut.get(j).getY() * (1 - alpha) + pointsFin.get(j).getY() * alpha;
				pointsIntermediaires.add(new Point((int)x, (int)y));
			}

			// Créer une nouvelle liste de triangles pour l'étape actuelle
			List<Triangle> trianglesIntermediaires = new ArrayList<>();
			for (Triangle triangle : trianglesEntree) {
			    Point a = pointsIntermediaires.get(triangle.getP1Index());
			    Point b = pointsIntermediaires.get(triangle.getP2Index());
			    Point c = pointsIntermediaires.get(triangle.getP3Index());
			    trianglesIntermediaires.add(new Triangle(a, b, c, triangle.getP1Index(), triangle.getP2Index(), triangle.getP3Index()));
			}

			// Créer une nouvelle image pour l'étape actuelle
			BufferedImage imageIntermediaire = new BufferedImage(originalImage.getWidth(), originalImage.getHeight(), originalImage.getType());
			for (int x = 0; x < originalImage.getWidth(); x++) {
				for (int y = 0; y < originalImage.getHeight(); y++) {
					Point pixel = new Point(x, y);

					// Trouver le triangle contenant le pixel
					Triangle triangleContenant = null;
					for (Triangle triangle : trianglesIntermediaires) {
						if (triangle.contient(pixel)) {
							triangleContenant = triangle;
							break;
						}
					}

					if (triangleContenant != null) {
						// Calculer les coordonnées barycentriques du pixel par rapport au triangle trouvé
						double[] baryCoords = calculerCoordonneesBarycentrique(pixel, triangleContenant);

						// Utiliser les coordonnées barycentriques pour trouver la position correspondante dans le triangle de départ
						Triangle triangleEntree = trouverTriangle(trianglesEntree, triangleContenant);
						Point positionEntree = recupererPositionBarycentrique(triangleEntree, baryCoords);
						int couleurEntree = getColor(originalImage, positionEntree);

						// Utiliser les coordonnées barycentriques pour trouver la position correspondante dans le triangle de l'image de fin
						Triangle triangleSortie = trouverTriangle(trianglesSortie, triangleContenant);
						Point positionSortie = recupererPositionBarycentrique(triangleSortie, baryCoords);
						int couleurSortie = getColor(finalImage, positionSortie);

						// Interpoler les couleurs pour obtenir la couleur finale
						int couleurInterpole = interpolationCouleur(couleurEntree, couleurSortie, alpha);

						// Définir cette couleur dans l'image intermédiaire
						imageIntermediaire.setRGB(x, y, couleurInterpole);
					}
				}
			}
			res[i] = imageIntermediaire;
		}
		return res;
	}

	/**
	 * Dessine les triangles sur l'image donnée.
	 *
	 * @param image l'image sur laquelle dessiner les triangles
	 * @param triangles la liste des triangles à dessiner
	 * @return l'image avec les triangles dessinés
	 */
	private static BufferedImage dessinerTriangles(BufferedImage image, List<Triangle> triangles) {
		BufferedImage imageAvecTriangles = new BufferedImage(image.getWidth(), image.getHeight(), image.getType());
		Graphics2D g2d = imageAvecTriangles.createGraphics();
		g2d.drawImage(image, 0, 0, null);
		g2d.setColor(Color.RED);
		for (Triangle triangle : triangles) {
	        int[] xPoints = {triangle.getPoint1().getX(), triangle.getPoint2().getX(), triangle.getPoint3().getX()};
	        int[] yPoints = {triangle.getPoint1().getY(), triangle.getPoint2().getY(), triangle.getPoint3().getY()};
	        g2d.drawPolygon(xPoints, yPoints, 3);
	    }
		g2d.dispose();
		return imageAvecTriangles;
	}

	/**
	 * Calcule les coordonnées barycentriques d'un point donné par rapport à un triangle.
	 *
	 * @param p le point dont les coordonnées barycentriques doivent être calculées
	 * @param triangle le triangle par rapport auquel les coordonnées barycentriques sont calculées
	 * @return un tableau contenant les coordonnées barycentriques {alpha, beta, gamma}
	 */
	private static double[] calculerCoordonneesBarycentrique(Point p, Triangle triangle) {
		// Coordonnées des sommets du triangle
		double xA = triangle.getPoint1().getX();
		double yA = triangle.getPoint1().getY();
		double xB = triangle.getPoint2().getX();
		double yB = triangle.getPoint2().getY();
		double xC = triangle.getPoint3().getX();
		double yC = triangle.getPoint3().getY();

		// Coordonnées du point p
		double xP = p.getX();
		double yP = p.getY();

		// Calcul de l'aire totale du triangle ABC 
		double aireABC = xA * (yB - yC) + xB * (yC - yA) + xC * (yA - yB);

		// Calcul des aires des sous-triangles formés avec P 
		double airePBC = xP * (yB - yC) + xB * (yC - yP) + xC * (yP - yB);
		double airePCA = xP * (yC - yA) + xC * (yA - yP) + xA * (yP - yC);
		double airePAB = xP * (yA - yB) + xA * (yB - yP) + xB * (yP - yA);

		// Coordonnées barycentriques
		double alpha = airePBC / aireABC;
		double beta = airePCA / aireABC;
		double gamma = airePAB / aireABC;

		return new double[]{alpha, beta, gamma};
	}

	/**
	 * Trouve et retourne un triangle spécifique dans une liste de triangles.
	 *
	 * @param triangles la liste des triangles dans laquelle chercher
	 * @param triangleInter le triangle à trouver, identifié par les index de ses sommets
	 * @return le triangle correspondant dans la liste, ou null si non trouvé
	 */
	private static Triangle trouverTriangle(List<Triangle> triangles, Triangle triangleInter) {
	    for (Triangle triangle : triangles) {
	        if (triangle.getP1Index() == triangleInter.getP1Index() &&
	            triangle.getP2Index() == triangleInter.getP2Index() &&
	            triangle.getP3Index() == triangleInter.getP3Index()) {
	            return triangle;
	        }
	    }
	    return null;
	}


	/**
	 * Calcule la position barycentrique d'un point dans un triangle donné à partir des coordonnées barycentriques.
	 *
	 * @param triangle le triangle dans lequel se trouve le point
	 * @param baryCoords les coordonnées barycentriques du point
	 * @return la position du point sous forme de Point
	 */
	private static Point recupererPositionBarycentrique(Triangle triangle, double[] baryCoords) {
		 int x = (int)(baryCoords[0] * triangle.getPoint1().getX() + baryCoords[1] * triangle.getPoint2().getX() + baryCoords[2] * triangle.getPoint3().getX());
		 int y = (int)(baryCoords[0] * triangle.getPoint1().getY() + baryCoords[1] * triangle.getPoint2().getY() + baryCoords[2] * triangle.getPoint3().getY());

		// Assurez-vous que les coordonnées sont entières et dans les limites de l'image
		return new Point(x, y);
	}




	/**
	 * Récupère la couleur d'un pixel à une position donnée dans une image.
	 *
	 * @param image l'image à partir de laquelle la couleur doit être récupérée
	 * @param position la position du pixel sous forme de Point
	 * @return la couleur du pixel sous forme d'un entier
	 */
	private static int getColor(BufferedImage image, Point position) {
		int x = position.getX();
		int y = position.getY();

		// Vérifier que les coordonnées sont dans les limites de l'image
		return image.getRGB(x, y);
	}


	/**
	 * Interpole entre deux couleurs en utilisant un facteur alpha.
	 *
	 * @param colorEntree la couleur de départ sous forme d'un entier
	 * @param colorSortie la couleur d'arrivée sous forme d'un entier
	 * @param alpha le facteur d'interpolation (compris entre 0 et 1)
	 * @return la couleur interpolée sous forme d'un entier
	 */
	private static int interpolationCouleur(int colorEntree, int colorSortie, double alpha) {

		// On cree un objet Color pour pouvoir recuperer le rouge, vert et bleu avec les méthodes associées
		Color entreeColor = new Color(colorEntree);
		Color sortieColor = new Color(colorSortie);

		// On recupere le RGB
		int rEntree = entreeColor.getRed();
		int gEntree = entreeColor.getGreen();
		int bEntree = entreeColor.getBlue();

		int rSortie = sortieColor.getRed();
		int gSortie = sortieColor.getGreen();
		int bSortie = sortieColor.getBlue();

		// On interpole la couleur pour obtenir la couleur intermediaire a l'étape alpha
		int r = (int) ((1 - alpha) * rEntree + alpha * rSortie);
		int g = (int) ((1 - alpha) * gEntree + alpha * gSortie);
		int b = (int) ((1 - alpha) * bEntree + alpha * bSortie);

		// On retourne le resultat sous forme d'entier pour pouvoir l'utiliser avec BufferedImage
		Color couleurInterpolee = new Color(r,g,b);
		return couleurInterpolee.getRGB();
	}
}