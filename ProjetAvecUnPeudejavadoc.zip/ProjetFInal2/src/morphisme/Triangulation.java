package morphisme;
import java.util.ArrayList;

/**
 * Cette classe permet d'effectuer la triangulation de delaunay a partir de nouveaux points, et elle stocke la liste des triangles
 * qui se forment
 */

public class Triangulation {
	private ArrayList<Triangle> listeTriangle;
	
	
    /**
     * Constructeur de la classe Triangulation
     *
     * @param t Une liste de triangles initialisant la triangulation de Delaunay.
     */
	public Triangulation (ArrayList<Triangle> t){
		this.listeTriangle = t;
	}
	
    /**
     * Retourne la liste des triangles de la triangulation
     *
     * @return Une liste de triangles
     */
	public ArrayList<Triangle> getTriangles(){
		return this.listeTriangle;
	}
	
	
    /**
     * Retourne la liste des triangles qui sont affectés par l'ajout d'un nouveau point
     *
     * @param p Le nouveau point ajouté à la triangulation
     * @return Une liste de triangles qui doivent être retriangulés
     */
	public ArrayList<Triangle> aRelier(Point p){

		ArrayList<Triangle> tmp = new ArrayList<Triangle>();    

		//ajoute la liste des triangles concernés.
		//Attention il peut y avoir des doublons de points
		for (Triangle i : this.getTriangles()){
			if (p.distance(i.getCercle().getCentre()) < i.getCercle().getRayon()){
				tmp.add(i);
			}
		}

		return tmp;
	}


	/**
	 * Effectue la triangulation de Delaunay avec l'ajout d'un nouveau point.
	 *
	 * @param p Le nouveau point ajouté à la triangulation.
	 */    
	public void triangulation(Point p){
		ArrayList<Triangle> aTester = this.aRelier(p);
		ArrayList<Triangle> appartenance = this.aRelier(p);

		ArrayList<Droite> tabDroite = new ArrayList<Droite>();
		ArrayList<Droite> suppDroite = new ArrayList<Droite>();
		ArrayList<Triangle> suppr = new ArrayList<Triangle>();
		ArrayList<Triangle> tmp = new ArrayList<Triangle>();
		ArrayList<Triangle> tmpSuppr = new ArrayList<Triangle>();

		for (Triangle i : aTester){
			tabDroite.add(new Droite(i.getPoint1(),i.getPoint2()));
			tabDroite.add(new Droite(i.getPoint2(),i.getPoint3()));
			tabDroite.add(new Droite(i.getPoint1(),i.getPoint3()));
			tabDroite.add(new Droite(i.getPoint1(),p));
			tabDroite.add(new Droite(i.getPoint2(),p));
			tabDroite.add(new Droite(i.getPoint3(),p));
			tmp.add(new Triangle(i.getPoint1(), i.getPoint2(), p));
			tmp.add(new Triangle(i.getPoint1(), p, i.getPoint3()));
			tmp.add(new Triangle(p, i.getPoint2(), i.getPoint3()));
		}

		//supprime les doublons de tabDroite
		for (int i = 0 ; i< tabDroite.size();i++){
			for (int j = i+1 ; j<tabDroite.size() ;j++){
				if (tabDroite.get(i).memeDroite(tabDroite.get(j))){

					suppDroite.add(tabDroite.get(i));
				}
			}
		}


		for (Droite i : suppDroite){
			tabDroite.remove(i);
		}

		//elimine les droites qui se coupent
		for (int i= 0; i< tabDroite.size();i++){ 
			for ( int j = i+1 ; j<tabDroite.size();j++){ 
				if ((tabDroite.get(i).intersectionDroiteDroite(tabDroite.get(j))) && ( (tabDroite.get(i).getDebut() != tabDroite.get(j).getDebut() ) &&
						tabDroite.get(i).getDebut() != tabDroite.get(j).getFin() &&
						tabDroite.get(i).getFin() != tabDroite.get(j).getDebut() &&
						tabDroite.get(i).getFin() != tabDroite.get(j).getFin()) )  {
					appartenance = tabDroite.get(j).droiteAppartient(aTester);
					//j appartient pas aux vieux triangles
					if (appartenance.isEmpty()){
						tmpSuppr = tabDroite.get(i).droiteAppartient(aTester);
						for (Triangle k : tmpSuppr){
							suppr.add(k);
						}
						tmpSuppr = tabDroite.get(i).droiteAppartient(tmp);
						for (Triangle k : tmpSuppr){
							suppr.add(k);
						}
						//l'inverse
					}else{
						tmpSuppr = tabDroite.get(j).droiteAppartient(aTester);
						for (Triangle k : appartenance){
							suppr.add(k);
						}
						tmpSuppr = tabDroite.get(j).droiteAppartient(tmp);
						for (Triangle k : tmpSuppr){
							suppr.add(k);
						}
					}

				}
			}
		}
		//ajout des nouveaux triangles
		for (Triangle i :tmp){
			this.listeTriangle.add(i);
		}
		//suppression des triangles en trop
		for (Triangle i : suppr){
			this.listeTriangle.remove(i);
		}
		suppr.clear();
		tmp.clear();       
	}


}
