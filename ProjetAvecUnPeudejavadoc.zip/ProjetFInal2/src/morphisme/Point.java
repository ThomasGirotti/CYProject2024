package morphisme;

public class Point {
	private int x;
	private int y;
	private String nom;
	

    /**
     * Constructeur de la classe Point
     *
     * @param x Coordonnée x du point
     * @param y Coordonnée y du point
     * @param nom Le nom du point
     */
    public Point(int x, int y, String nom) {
		this(x, y);
		this.nom = nom;
	}

	
    /**
     * Constructeur de la classe Point
     *
     * @param x Coordonnée x du point
     * @param y Coordonnée y du point
     */
	public Point(int x, int y) {
		this.x = x;
        this.y = y;
	}

	
	 /**
     * Retourne la coordonnée x 
     *
     * @return La coordonnée x
     */
    public int getX() {
        return x;
    }

    /**
     * Définit la coordonnée x du point
     *
     * @param x La nouvelle coordonnée x
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * Retourne la coordonnée y du point
     *
     * @return La coordonnée y
     */
    public int getY() {
        return y;
    }

    /**
     * Définit la coordonnée y du point
     *
     * @param y La nouvelle coordonnée y
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * Définit le nom du point
     *
     * @param y Le nouveau nom
     */
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	
    /**
     * Retourne le nom du point
     *
     * @return le nom du point
     */
	public String getNom() {
		return this.nom;
	}

    /**
     * Vérifie si les deux points sont aux mêmes coordonnées
     *
     * @param p Le point à comparer
     * @return true si les points ont les mêmes coordonnées, false sinon
     */
	public boolean memeEndroit(Point p) {
		return (this.getX() == p.getX() && this.getY() == p.getY());
	}
	
	
    /**
     * Retourne une chaine de caracteres avec les infos du points
     *
     * @return les infos du point
     */
	@Override
	public String toString() {
		return "Point [x=" + x + ", y=" + y + "]";
	}

	
    /**
     * Calcule la distance entre ce point et un autre point 
     *
     * @param p Le deuxieme point
     * @return La distance entre notre point et le deuxieme en parametre
     */
	public float distance(Point p){
		return(int)(Math.sqrt(Math.pow(x-p.x, 2)+Math.pow(y-p.y, 2)));
	}
	
}