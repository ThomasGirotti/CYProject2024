package morphisme;

import java.util.ArrayList;

public class Triangle{
    public Point p1;
    public Point p2;
    public Point p3;
    public int p1Index;
    public int p2Index;
    public int p3Index;
    private Cercle cercle;
    
    public Cercle getCercle(){
        return this.cercle;
    }
    public Point getPoint1(){
        return this.p1 ;
    }
    public Point getPoint2(){
        return this.p2 ;
    }
    public Point getPoint3(){
        return this.p3 ;
    }
    public Triangle(Point p1,Point p2,Point p3){
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        Droite d1 = new Droite(p1,p2);
        Droite d2 = new Droite(p2,p3);
        Droite per1 = d1.perpendiculaire();
        Droite per2 = d2.perpendiculaire();
        
        this.cercle = new Cercle(per1.intersectionDroitePoint(per2),this.p1.distance(per1.intersectionDroitePoint(per2)));
    }
    
    public Triangle(Point p1,Point p2,Point p3,  int p1Index, int p2Index, int p3Index){
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        Droite d1 = new Droite(p1,p2);
        Droite d2 = new Droite(p2,p3);
        Droite per1 = d1.perpendiculaire();
        Droite per2 = d2.perpendiculaire();
        this.cercle = new Cercle(per1.intersectionDroitePoint(per2),this.p1.distance(per1.intersectionDroitePoint(per2)));
        this.p1Index = p1Index;
        this.p2Index = p2Index;
        this.p3Index = p3Index;
    }
    public boolean memeTriangle(Triangle t){
        boolean res = true;
        ArrayList<Point> listeP = new ArrayList<>();
        listeP.add(this.getPoint1());
        listeP.add(this.getPoint2());
        listeP.add(this.getPoint3());
        for (Point p : listeP){
            if ( !(p.memeEndroit(t.getPoint1()) || p.memeEndroit(t.getPoint2()) || p.memeEndroit(t.getPoint3()))) {
                res = false;
            }
        }
        return res;
    }
    public boolean contient(Point p){
        int eq1 = ( ( this.p1.getX() - p.getX()) * (this.p2.getY() - p.getY() ) ) - ( ( this.p1.getY() - p.getY() ) * (this.p2.getX() - p.getX()) );
        int eq2 = ( ( this.p2.getX() - p.getX()) * (this.p3.getY() - p.getY() ) ) - ( ( this.p2.getY() - p.getY() ) * (this.p3.getX() - p.getX()) );
        int eq3 = ( ( this.p3.getX() - p.getX()) * (this.p1.getY() - p.getY() ) ) - ( ( this.p3.getY() - p.getY() ) * (this.p1.getX() - p.getX()) );
        if ( (eq1 > 0 && eq2 >0 && eq3>0 ) || (eq1 < 0 && eq2 < 0 && eq3 <0)){
            return true;
        }else{
            return false;
        }
    
    }
	@Override
	public String toString() {
		return "Triangle [p1=" + p1 + ", p2=" + p2 + ", p3=" + p3 + ", p1Index=" + p1Index + ", p2Index=" + p2Index
				+ ", p3Index=" + p3Index + "]";
	}
    
}