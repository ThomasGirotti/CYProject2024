/**
 * 
 */
/**
 * 
 */
module morphisme {
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.media;
	requires java.desktop;
	exports morphisme;
}