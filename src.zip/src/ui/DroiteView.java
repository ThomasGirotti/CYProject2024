package ui;

import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

public class DroiteView {
    private PointView start;
    private PointView end;
    private Line line;

    public DroiteView(PointView start, PointView end) {
        this.start = start;
        this.end = end;
        this.line = new Line();
        this.line.setStroke(Color.RED);
        update();
    }

    public void update() {
        line.setStartX(start.getCircle().getCenterX() + start.getCircle().getTranslateX());
        line.setStartY(start.getCircle().getCenterY() + start.getCircle().getTranslateY());
        line.setEndX(end.getCircle().getCenterX() + end.getCircle().getTranslateX());
        line.setEndY(end.getCircle().getCenterY() + end.getCircle().getTranslateY());
    }

    public PointView getStart() {
        return start;
    }

    public PointView getEnd() {
        return end;
    }

    public Line getLine() {
        return line;
    }

    public boolean intersects(LineView other) {
        double x1 = this.getStart().getCircle().getCenterX();
        double y1 = this.getStart().getCircle().getCenterY();
        double x2 = this.getEnd().getCircle().getCenterX();
        double y2 = this.getEnd().getCircle().getCenterY();
    
        double x3 = other.getStart().getCircle().getCenterX();
        double y3 = other.getStart().getCircle().getCenterY();
        double x4 = other.getEnd().getCircle().getCenterX();
        double y4 = other.getEnd().getCircle().getCenterY();
    
        double denominator = ((x1 - x2) * (y3 - y4)) - ((y1 - y2) * (x3 - x4));
    
        if (denominator == 0) {
            return false; // The lines are parallel
        }
    
        double numerator1 = ((y1 - y3) * (x3 - x4)) - ((x1 - x3) * (y3 - y4));
        double numerator2 = ((y1 - y2) * (x1 - x3)) - ((x1 - x2) * (y1 - y3));
    
        double r = numerator1 / denominator;
        double s = numerator2 / denominator;
    
        return (r >= 0 && r <= 1) && (s >= 0 && s <= 1);
    }
}