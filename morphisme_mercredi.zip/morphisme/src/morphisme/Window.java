package morphisme;

import javafx.application.*;
import javafx.concurrent.Task;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Screen;
import javafx.stage.Stage;
import java.awt.Desktop;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Paths;
import java.util.ArrayList;

public class Window extends Application implements ImageImportListener {
    private ArrayList<ConteneurImage> conteneursImages = new ArrayList<>();
    private VBox miniaturesBox = new VBox();
    private ConteneurImage conteneurActif;
    private Stage primaryStage;
    private int screenX;
    private int screenY;
    private int gifSpeed = 60;
    private int indicator;

    public void start(Stage primaryStage) throws Exception {
        this.primaryStage = primaryStage;
        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
        screenX = (int) screenBounds.getWidth();
        screenY = (int) screenBounds.getHeight();
        primaryStage.setX(screenBounds.getMinX());
        primaryStage.setY(screenBounds.getMinY());
        primaryStage.setWidth(screenX);
        primaryStage.setHeight(screenY);
        primaryStage.setMaximized(true);
        primaryStage.setTitle("Morpheus");
        primaryStage.getIcons().add(new Image("file:src/images/Visage.png"));
        showHomeScreen();
        primaryStage.show();
    }

    public void showHomeScreen() {
        conteneursImages.clear();
        miniaturesBox.getChildren().clear();
        conteneurActif = null;
        indicator = 0;
        ImageView gif1 = new ImageView(new Image("images/Triangle.png"));
        gif1.setFitWidth(0.25 * screenX);
        gif1.setFitHeight(0.25 * screenX);
        ImageView gif2 = new ImageView(new Image("images/Coeur.png"));
        gif2.setFitWidth(0.25 * screenX);
        gif2.setFitHeight(0.25 * screenX);
        ImageView gif3 = new ImageView(new Image("images/Visage.png"));
        gif3.setFitWidth(0.25 * screenX);
        gif3.setFitHeight(0.25 * screenX);
        Button m1 = new Button("Morphing de formes unies simples");
        m1.setGraphic(gif1);
        Button m2 = new Button("Morphing de formes unies arrondies");
        m2.setGraphic(gif2);
        Button m3 = new Button("Morphing d'images");
        m3.setGraphic(gif3);
        m1.getStyleClass().add("m1");
        m2.getStyleClass().add("m2");
        m3.getStyleClass().add("m3");

        HBox morphMode = new HBox();
        morphMode.setAlignment(Pos.CENTER);
        morphMode.setSpacing(0.05 * screenX);
        m1.setPrefWidth(0.25 * screenX);
        m1.setPrefHeight(0.25 * screenY);
        m2.setPrefWidth(0.25 * screenX);
        m2.setPrefHeight(0.25 * screenY);
        m3.setPrefWidth(0.25 * screenX);
        m3.setPrefHeight(0.25 * screenY);
        morphMode.getChildren().addAll(m1, m2, m3);
        m1.setOnAction(e -> showMorphing1());
        m2.setOnAction(e -> showMorphing2());
        m3.setOnAction(e -> showMorphing3());
        Scene scene = new Scene(morphMode);
        scene.getStylesheets().add("styles/window.css");
        primaryStage.setScene(scene);
    }

    private void initializeMorphingUI() {
        // Bouton pour revenir à l'accueil
        Button Accueil = new Button("Accueil");
        Accueil.setOnAction(e -> showHomeScreen());
        Accueil.getStyleClass().add("bouton-accueil");
        // Initialisation des conteneurs d'images par défaut
        ConteneurImage conteneur1;
        ConteneurImage conteneur2;
        if (indicator == 1) {
            conteneur1 = new ConteneurImageMorph1(primaryStage, screenX, screenY, this);
            conteneur2 = new ConteneurImageMorph1(primaryStage, screenX, screenY, this);
        } else if (indicator == 2) {
            conteneur1 = new ConteneurImageMorph2(primaryStage, screenX, screenY, this);
            conteneur2 = new ConteneurImageMorph2(primaryStage, screenX, screenY, this);
        } else if (indicator == 3) {
            conteneur1 = new ConteneurImageMorph3(primaryStage, screenX, screenY, this);
            conteneur2 = new ConteneurImageMorph3(primaryStage, screenX, screenY, this);
        } else {
            conteneur1 = new ConteneurImage(primaryStage, screenX, screenY, this);
            conteneur2 = new ConteneurImage(primaryStage, screenX, screenY, this);
        }
        conteneursImages.add(conteneur1);
        conteneursImages.add(conteneur2);
        conteneurActif = conteneur1;

        // Liste des miniatures à gauche
        miniaturesBox.setSpacing(10);
        miniaturesBox.setPrefWidth(0.13 * screenX);
        miniaturesBox.setPrefHeight(0.90 * screenY);
        miniaturesBox.setAlignment(Pos.CENTER);

        // Ajouter les conteneurs d'images à la liste des miniatures
        for (ConteneurImage ci : conteneursImages) {
            Button miniatureButton = new Button();
            miniatureButton.getStyleClass().add("miniature-button");
            miniatureButton.setPrefSize(screenX * 0.08, screenX * 0.08);
            ImageView imageView = new ImageView(ci.getPhoto().getImageView().getImage());
            imageView.setFitWidth(screenX * 0.08);
            imageView.setFitHeight(screenX * 0.08);
            miniatureButton.setGraphic(imageView);
            miniatureButton.setOnAction(e -> setActiveConteneur(ci));
            miniaturesBox.getChildren().add(miniatureButton);
        }

        // Bouton pour ajouter un nouveau conteneur d'image
        Button addConteneurButton = new Button("+");
        addConteneurButton.getStyleClass().add("add-conteneur-button");
        addConteneurButton.setPrefSize(screenX * 0.085, screenX * 0.085);
        addConteneurButton.setOnAction(e -> addConteneurImage(miniaturesBox, addConteneurButton));
        miniaturesBox.getChildren().add(addConteneurButton);

        // ScrollPane pour la liste des miniatures
        ScrollPane scrollPane = new ScrollPane(miniaturesBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setMaxHeight(0.90 * screenY);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        // Conteneur actif au centre
        Pane conteneurActifPane = new Pane();
        conteneurActifPane.getChildren().add(conteneurActif.getConteneurImage());
        conteneurActifPane.setMaxHeight(0.90 * screenY);

        // Boutons de gestion à droite
        VBox boutonsGestion = new VBox();
        boutonsGestion.setSpacing(0.05 * screenY);
        boutonsGestion.setAlignment(Pos.CENTER);
        boutonsGestion.setPrefWidth(0.15 * screenX);
        
        // Ajout de la dernière courbe
        VBox addLastLine = new VBox(10);
        addLastLine.getStyleClass().add("image-management-box");
        addLastLine.setAlignment(Pos.CENTER);
        Label addLastLineLabel = new Label("Fermer la forme");
        addLastLineLabel.getStyleClass().add("image-management-label");
        addLastLineLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        Button addLastLineButton = new Button("Fermer");
        addLastLineButton.getStyleClass().add("image-management-button");
        addLastLineButton.setPrefSize(0.07 * screenX, 0.05 * screenY);
        addLastLineButton.setOnAction(e -> conteneurActif.addLastLine());
        addLastLine.getChildren().addAll(addLastLineLabel, addLastLineButton);
        
        // Section de gestion des images
        VBox imageManagementBox = new VBox(10);
        imageManagementBox.getStyleClass().add("image-management-box");
        imageManagementBox.setAlignment(Pos.CENTER);
        Label imageManagementLabel = new Label("Gestion de l'image actuelle");
        imageManagementLabel.getStyleClass().add("image-management-label");
        imageManagementLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        Button pointReset = new Button("Réinitialiser Points");
        pointReset.getStyleClass().add("image-management-button");
        Button fileReset = new Button("Réinitialiser Image");
        fileReset.getStyleClass().add("image-management-button");
        Button supprimerConteneur = new Button("Supprimer Conteneur");
        supprimerConteneur.getStyleClass().add("image-management-button");
        pointReset.setPrefSize(0.07 * screenX, 0.05 * screenY);
        fileReset.setPrefSize(0.07 * screenX, 0.05 * screenY);
        supprimerConteneur.setPrefSize(0.07 * screenX, 0.05 * screenY);
        pointReset.setOnAction(e -> conteneurActif.resetPoints());
        fileReset.setOnAction(e -> {
            conteneurActif.fileReset();
        });
        supprimerConteneur.setOnAction(e -> supprimerConteneur(conteneurActif));
        imageManagementBox.getChildren().addAll(imageManagementLabel, pointReset, fileReset, supprimerConteneur);

        // Section de gestion du dossier
        VBox folderManagementBox = new VBox(10);
        folderManagementBox.setAlignment(Pos.CENTER);
        folderManagementBox.getStyleClass().add("folder-management-box");
        Label folderManagementLabel = new Label("Gestion de toutes les images");
        folderManagementLabel.getStyleClass().add("folder-management-label");
        folderManagementLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        Button globalPointReset = new Button("Réinitialiser Points");
        globalPointReset.getStyleClass().add("folder-management-button");
        Button globalFileReset = new Button("Réinitialiser Images");
        globalFileReset.getStyleClass().add("folder-management-button");
        Button globalConteneurReset = new Button("Réinitialiser Conteneurs");
        globalConteneurReset.getStyleClass().add("folder-management-button");
        globalPointReset.setPrefSize(0.07 * screenX, 0.05 * screenY);
        globalFileReset.setPrefSize(0.07 * screenX, 0.05 * screenY);
        globalConteneurReset.setPrefSize(0.07 * screenX, 0.05 * screenY);
        globalPointReset.setOnAction(e -> globalResetPoints());
        globalFileReset.setOnAction(e -> {
            globalFileReset();
            onImageImported();
        });
        globalConteneurReset.setOnAction(e -> {
            globalConteneurReset();
        });
        folderManagementBox.getChildren().addAll(folderManagementLabel, globalPointReset, globalFileReset, globalConteneurReset);
        
        // Section de génération
        VBox generationBox = new VBox(10);
        generationBox.getStyleClass().add("generation-box");
        generationBox.setAlignment(Pos.CENTER);
        Label generationLabel = new Label("Génération du gif");
        generationLabel.getStyleClass().add("generation-label");
        generationLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        RadioButton radio1 = new RadioButton("Rapide");
        RadioButton radio2 = new RadioButton("Normal");
        RadioButton radio3 = new RadioButton("Lent");
        radio1.setOnAction(e -> gifSpeed = 40);
        radio2.setOnAction(e -> gifSpeed = 75);
        radio3.setOnAction(e -> gifSpeed = 140);
        ToggleGroup group = new ToggleGroup();
        radio1.setToggleGroup(group);
        radio1.getStyleClass().add("radio-button-minimal");
        radio2.setToggleGroup(group);
        radio2.getStyleClass().add("radio-button-minimal");
        radio3.setToggleGroup(group);
        radio3.getStyleClass().add("radio-button-minimal");
        radio2.setSelected(true);
        VBox boutonsRadiosConteneur = new VBox(5);
        boutonsRadiosConteneur.getStyleClass().add("radio-button");
        boutonsRadiosConteneur.setAlignment(Pos.CENTER_LEFT);
        boutonsRadiosConteneur.getChildren().addAll(radio1, radio2, radio3);
        HBox boutonsRadios = new HBox(10);
        boutonsRadios.setAlignment(Pos.CENTER);
        boutonsRadios.getChildren().addAll(boutonsRadiosConteneur);
        Button boutonValidation = new Button("Générer");
        boutonValidation.getStyleClass().add("generation-button");
        boutonValidation.setPrefSize(0.07 * screenX, 0.05 * screenY);
        boutonValidation.setOnAction(e -> openGIF());
        Button boutonExportation = new Button("Exporter");
        boutonExportation.getStyleClass().add("generation-button");
        boutonExportation.setPrefSize(0.07 * screenX, 0.05 * screenY);
        boutonExportation.setOnAction(e -> exporterImage());
        generationBox.getChildren().addAll(generationLabel, boutonsRadios, boutonValidation, boutonExportation);
        if (indicator == 2) {
        boutonsGestion.getChildren().addAll(addLastLine, imageManagementBox, folderManagementBox, generationBox);
        } else {
        boutonsGestion.getChildren().addAll(imageManagementBox, folderManagementBox, generationBox);
        }

        // Ajout à l'interface principale
        VBox root = new VBox();
        root.setAlignment(Pos.TOP_LEFT);
        HBox topContainer = new HBox();
        topContainer.getChildren().add(Accueil);
        HBox mainContainer = new HBox();
        mainContainer.getChildren().addAll(scrollPane, conteneurActifPane, boutonsGestion);
        mainContainer.setSpacing(0.05 * screenX);
        mainContainer.setAlignment(Pos.CENTER);
        root.getChildren().addAll(topContainer, mainContainer);
        Scene scene = new Scene(root, screenX, screenY);
        scene.getStylesheets().add("styles/window.css");
        primaryStage.setScene(scene);
    }

    private void addConteneurImage(VBox miniaturesBox, Button addConteneurButton) {
        miniaturesBox.getChildren().remove(addConteneurButton);
        ConteneurImage conteneur;
        if (indicator == 1) {
            conteneur = new ConteneurImageMorph1(primaryStage, screenX, screenY, this);
        } else if (indicator == 2) {
            conteneur = new ConteneurImageMorph2(primaryStage, screenX, screenY, this);
        } else if (indicator == 3) {
            conteneur = new ConteneurImageMorph3(primaryStage, screenX, screenY, this);
        } else {
            conteneur = new ConteneurImage(primaryStage, screenX, screenY, this);
        }
        conteneursImages.add(conteneur);
        Button miniatureButton = new Button();
        miniatureButton.getStyleClass().add("miniature-button");
        miniatureButton.setPrefSize(screenX * 0.08, screenX * 0.08);
        ImageView imageView = new ImageView(conteneur.getPhoto().getImageView().getImage());
        imageView.setFitWidth(screenX * 0.08);
        imageView.setFitHeight(screenX * 0.08);
        miniatureButton.setGraphic(imageView);
        miniatureButton.setOnAction(e -> setActiveConteneur(conteneur));
        miniaturesBox.getChildren().add(miniatureButton);
        miniaturesBox.getChildren().add(addConteneurButton);
        addConteneurButton.getStyleClass().add("add-conteneur-button");
    }

    private void setActiveConteneur(ConteneurImage conteneur) {
        conteneurActif = conteneur;
        if (primaryStage.getScene().getRoot() instanceof VBox) {
            VBox root = (VBox) primaryStage.getScene().getRoot();
            if (root.getChildren().size() > 1 && root.getChildren().get(1) instanceof HBox) {
                HBox mainContainer = (HBox) root.getChildren().get(1);
                if (mainContainer.getChildren().size() > 1 && mainContainer.getChildren().get(1) instanceof Pane) {
                    Pane conteneurActifPane = (Pane) mainContainer.getChildren().get(1);
                    conteneurActifPane.getChildren().clear();
                    conteneurActifPane.getChildren().add(conteneur.getConteneurImage());
                    if (conteneur instanceof ConteneurImageMorph1) {
                        ((ConteneurImageMorph1) conteneur).updateLines();
                    } else if (conteneur instanceof ConteneurImageMorph2) {
                        ((ConteneurImageMorph2) conteneur).updateCurves();
                    } else if (conteneur instanceof ConteneurImageMorph3) {
                        ((ConteneurImageMorph3) conteneur).drawDroite();
                    }
                }
            }
        }
    }

    public void supprimerConteneur(ConteneurImage conteneur) {
        if (conteneursImages.size() > 2) {
            conteneursImages.remove(conteneur);
            miniaturesBox.getChildren().clear();
            for (ConteneurImage ci : conteneursImages) {
                Button miniatureButton = new Button();
                miniatureButton.getStyleClass().add("miniature-button");
                miniatureButton.setPrefSize(screenX * 0.08, screenX * 0.08);
                ImageView imageView = new ImageView(ci.getPhoto().getImageView().getImage());
                imageView.setFitWidth(screenX * 0.08);
                imageView.setFitHeight(screenX * 0.08);
                miniatureButton.setGraphic(imageView);
                miniatureButton.setOnAction(e -> setActiveConteneur(ci));
                miniaturesBox.getChildren().add(miniatureButton);
            }
            Button addConteneurButton = new Button("+");
            addConteneurButton.getStyleClass().add("add-conteneur-button");
            addConteneurButton.setPrefSize(screenX * 0.085, screenX * 0.085);
            addConteneurButton.setOnAction(e -> addConteneurImage(miniaturesBox, addConteneurButton));
            miniaturesBox.getChildren().add(addConteneurButton);
            conteneurActif = conteneursImages.get(0);
            Pane conteneurActifPane = (Pane) ((HBox) primaryStage.getScene().getRoot()).getChildren().get(2);
            conteneurActifPane.getChildren().clear();
            conteneurActifPane.getChildren().add(conteneurActif.getConteneurImage());
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Vous ne pouvez pas supprimer de conteneur.\nIl doit y avoir au moins deux conteneurs d'images.");
            alert.showAndWait();
        }
    }

    @Override
    public void onImageImported() {
        for (int i = 0; i < conteneursImages.size(); i++) {
            Button button = (Button) miniaturesBox.getChildren().get(i);
            ConteneurImage conteneur = conteneursImages.get(i);
            ImageView imageView = new ImageView(conteneur.getPhoto().getImageView().getImage());
            imageView.setFitWidth(screenX * 0.08);
            imageView.setFitHeight(screenX * 0.08);
            imageView.setPreserveRatio(true);
            button.setGraphic(imageView);
        }
    }

    private void globalResetPoints() {
        for (ConteneurImage ci : conteneursImages) {
            ci.resetPoints();
        }
    }

    private void globalFileReset() {
        for (ConteneurImage ci : conteneursImages) {
            ci.fileReset();
        }
        onImageImported();
    }

    private void globalConteneurReset() {
        globalFileReset();
        conteneursImages.clear();
        miniaturesBox.getChildren().clear();
        conteneurActif = null;
        switch (indicator) {
            case 1:
                showMorphing1();
                break;
            case 2:
                showMorphing2();
                break;
            case 3:
                showMorphing3();
                break;
            default:
                break;
        }
    }

    @Override
    public boolean verificationTaillePhoto(Image photo) {
        for (ConteneurImage ci : conteneursImages) {
            if (ci.getPhoto().getImageView().getImage() != null) {
                Image image = ci.getPhoto().getImageView().getImage();
                if (image.getWidth() != photo.getWidth() || image.getHeight() != photo.getHeight()) {
                    String warningText = "Les images doivent être de même taille.\nVeuillez importer une image de la même taille que les autres ou réinitialiser les images.";
                    Label label = new Label(warningText);
                    label.setWrapText(true);
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.getDialogPane().setContent(label);
                    alert.showAndWait();
                    return false;
                }
            }
        }
        return true;
    }

    private boolean verifierConditions() {
        int maxPoints = 0;
        boolean sameNumberOfPoints = true;
        int firstImagePoints = conteneursImages.get(0).getPoints().size();
        for (ConteneurImage ci : conteneursImages) {
            if (ci.getPhoto().getImageView().getImage() == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Veuillez importer une image pour chaque conteneur.");
                alert.showAndWait();
                return false;
            }
            int pointsCount = ci.getPoints().size();
            if (pointsCount < 3) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Veuillez choisir au moins trois points sur chaque image.");
                alert.showAndWait();
                return false;
            }
            if (pointsCount != firstImagePoints) {
                sameNumberOfPoints = false;
            }
            if (pointsCount > maxPoints) {
                maxPoints = pointsCount;
            }
        }
        if (!sameNumberOfPoints) {
            String warningText = "Toutes les images n'ont pas le même nombre de points.\nVérifiez que chaque image possèdent " + maxPoints + " points qui est le maximum actuel entre vos images.";
            Label label = new Label(warningText);
            label.setWrapText(true);
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.getDialogPane().setContent(label);
            alert.showAndWait();
            return false;
        }
        return true;
    }

    private boolean generateMorphing() {
        if(verifierConditions()) {
            switch (indicator) {
                case 1:
                    int gifSteps = (gifSpeed * (conteneursImages.size() - 1)) + (conteneursImages.size() - 1);
                    BufferedImage[] tab = new BufferedImage[gifSteps];
                    SimpleImageMorph morph = null;
                    int currentIndex = 0;
                    for (int i = 0; i < conteneursImages.size() - 1; i++) {
                        ConteneurImage conteneurDepart = conteneursImages.get(i);
                        ConteneurImage conteneurArrive = conteneursImages.get(i + 1);
                        ArrayList<Point> pointsDebut = new ArrayList<>();
                        ArrayList<Point> pointsFin = new ArrayList<>();
                        for (PointView pointView : conteneurDepart.getPoints()) {
                            pointsDebut.add(new Point((int) pointView.getPoint().getX(), (int) pointView.getPoint().getY()));
                        }
                        for (PointView pointView : conteneurArrive.getPoints()) {
                            pointsFin.add(new Point((int) pointView.getPoint().getX(), (int) pointView.getPoint().getY()));
                        }
                        String imagePath = null;
                        try {
                            URI uri = new URI(conteneurDepart.getPhoto().getImage().getUrl());
                            imagePath = Paths.get(uri).toString();
                        } catch (URISyntaxException e) {
                            e.printStackTrace();
                        }
                        try {
                            morph = new SimpleImageMorph(pointsDebut, pointsFin, gifSpeed, imagePath);
                            BufferedImage[] morphImages = morph.morphing();
                            for (BufferedImage image : morphImages) {
                                tab[currentIndex] = image;
                                currentIndex++;
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    try {
                        morph.creerGif(tab, gifSteps);
                        return true;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;
                case 2:
                    int gifSteps2 = (gifSpeed * (conteneursImages.size() - 1)) + (conteneursImages.size() - 1);
                    BufferedImage[] tab2 = new BufferedImage[gifSteps2];
                    CurvedImageMorph morph2 = null;
                    int currentIndex2 = 0;
                    for (int i = 0; i < conteneursImages.size() - 1; i++) {
                        ConteneurImage conteneurDepart = conteneursImages.get(i);
                        ConteneurImage conteneurArrive = conteneursImages.get(i + 1);
                        ArrayList<Point> pointsDebut = new ArrayList<>();
                        ArrayList<Point> pointsFin = new ArrayList<>();
                        for (PointView pointView : conteneurDepart.getPoints()) {
                            Point p = new Point((int) pointView.getPoint().getX(), (int) pointView.getPoint().getY());
                            pointsDebut.add(p);
                            if (pointView.getLabel().getText().startsWith("P") && !pointView.getLabel().getText().startsWith("P0")) {
                                pointsDebut.add(p);
                            }
                        }
                        for (PointView pointView : conteneurArrive.getPoints()) {
                            Point p = new Point((int) pointView.getPoint().getX(), (int) pointView.getPoint().getY());
                            pointsFin.add(p);
                            if (pointView.getLabel().getText().startsWith("P") && !pointView.getLabel().getText().startsWith("P0")) {
                                pointsFin.add(p);
                            }
                        }
                        String imagePath = null;
                        try {
                            URI uri = new URI(conteneurDepart.getPhoto().getImage().getUrl());
                            imagePath = Paths.get(uri).toString();
                        } catch (URISyntaxException e) {
                            e.printStackTrace();
                        }
                        try {
                            morph2 = new CurvedImageMorph(pointsDebut, pointsFin, gifSpeed, imagePath);
                            BufferedImage[] morphImages = morph2.morphing();
                            for (BufferedImage image : morphImages) {
                                tab2[currentIndex2] = image;
                                currentIndex2++;
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    try {
                        morph2.creerGif(tab2, gifSteps2);
                        return true;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;
                case 3:
                    int gifSteps3 = (gifSpeed * (conteneursImages.size() - 1)) + (conteneursImages.size() - 1);
                    BufferedImage[] tab3 = new BufferedImage[gifSteps3];
                    FullImageMorph morph3 = null;
                    int currentIndex3 = 0;
                    for (int i = 0; i < conteneursImages.size() - 1; i++) {
                        ConteneurImage conteneurDepart = conteneursImages.get(i);
                        ConteneurImage conteneurArrive = conteneursImages.get(i + 1);
                        ArrayList<Point> pointsDebut = new ArrayList<>();
                        ArrayList<Point> pointsFin = new ArrayList<>();
                        for (PointView pointView : conteneurDepart.getPoints()) {
                            pointsDebut.add(new Point((int) pointView.getPoint().getX(), (int) pointView.getPoint().getY()));
                        }
                        for (PointView pointView : conteneurArrive.getPoints()) {
                            pointsFin.add(new Point((int) pointView.getPoint().getX(), (int) pointView.getPoint().getY()));
                        }
                        String imagePath = null;
                        String imagePath2 = null;
                        try {
                            URI uri = new URI(conteneurDepart.getPhoto().getImage().getUrl());
                            imagePath = Paths.get(uri).toString();
                            URI uri2 = new URI(conteneurArrive.getPhoto().getImage().getUrl());
                            imagePath2 = Paths.get(uri2).toString();
                        } catch (URISyntaxException e) {
                            e.printStackTrace();
                        }
                        try {
                            morph3 = new FullImageMorph(pointsDebut, pointsFin, gifSpeed, imagePath, imagePath2);
                            BufferedImage[] morphImages = morph3.morphing();
                            for (BufferedImage image : morphImages) {
                                tab3[currentIndex3] = image;
                                currentIndex3++;
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    try {
                        morph3.creerGif(tab3, gifSteps3);
                        return true;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;
                default:
                    break;
            }
        }
        return false;
    }

    private void openGIF() {
        if (verifierConditions()){
            LoadingWindow loadingWindow = new LoadingWindow();
            loadingWindow.show(primaryStage);
            Task<Boolean> task = new Task<>() {
                @Override
                protected Boolean call() {
                    return generateMorphing();
                }
                @Override
                protected void succeeded() {
                    super.succeeded();
                    loadingWindow.close();
                    try {
                        File file = new File("morph.gif");
                        Desktop.getDesktop().open(file);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                @Override
                protected void failed() {
                    super.failed();
                    loadingWindow.close();
                    Alert alert = new Alert(Alert.AlertType.ERROR, "La génération du GIF a échoué.");
                    alert.showAndWait();
                }
            };
            Thread thread = new Thread(task);
            thread.setDaemon(true);
            thread.start();
        }
}

    private void exporterImage() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Sauvegarder le GIF");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("GIF Files", "*.gif"));
        File file = fileChooser.showSaveDialog(primaryStage);
        if (file != null) {
            LoadingWindow loadingWindow = new LoadingWindow();
            loadingWindow.show(primaryStage);
            Task<Void> task = new Task<>() {
                @Override
                protected Void call() {
                    if (generateMorphing()) {
                        File source = new File("morph.gif");
                        source.renameTo(file);
                    }
                    return null;
                }
                @Override
                protected void succeeded() {
                    super.succeeded();
                    loadingWindow.close();
                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Le GIF a été exporté avec succès.");
                    alert.showAndWait();
                }
                @Override
                protected void failed() {
                    super.failed();
                    loadingWindow.close();
                    Alert alert = new Alert(Alert.AlertType.ERROR, "L'exportation du GIF a échoué.");
                    alert.showAndWait();
                }
            };
            Thread thread = new Thread(task);
            thread.setDaemon(true);
            thread.start();
        }
    }

    public void showMorphing1() {
        indicator = 1;
        initializeMorphingUI();
    }

    public void showMorphing2() {
        indicator = 2;
        initializeMorphingUI();
    }

    public void showMorphing3() {
        indicator = 3;
        initializeMorphingUI();
    }

    public static void main(String[] args) {
        launch(args);
    }
}