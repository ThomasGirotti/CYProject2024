package morphisme;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class LoadingWindow {
    private Stage loadingStage;
    public void show(Stage ownerStage) {
        loadingStage = new Stage();
        loadingStage.initOwner(ownerStage);
        loadingStage.initModality(Modality.WINDOW_MODAL);
        loadingStage.setTitle("Génération en cours");
        ProgressIndicator progressIndicator = new ProgressIndicator();
        Label loadingLabel = new Label("Génération du GIF en cours...");
        VBox vbox = new VBox(20);
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(progressIndicator, loadingLabel);
        Scene scene = new Scene(vbox, 300, 200);
        loadingStage.setScene(scene);
        loadingStage.show();
    }

    public void close() {
        loadingStage.close();
    }
}