package morphisme;

import java.util.ArrayList;

public class Droite{
	private float a;
	private float b;
	private Point debut;
	private Point fin;

	public Droite(Point p1, Point p2){
		this.a =  (float) ((p2.getY() - p1.getY()) / (p2.getX() - p1.getX() + 0.000001));
		this.b = p1.getY() -( this.a * p1.getX());
		this.debut = p1;
		this.fin = p2;
	}
	public String toString(){
		return this.getDebut().toString() + this.getFin().toString();
	}
	public float getA() {
		return a;
	}
	public void setA(float a) {
		this.a = a;
	}
	public float getB() {
		return b;
	}
	public Point getDebut() {
		return this.debut;
	}
	public Point getFin() {
		return this.fin;
	}
	public void setB(float b) {
		this.b = b;
	}
	//donne un semble de triangle et renvoi a quels triangles cette droite appartient
	public ArrayList<Triangle> droiteAppartient(ArrayList<Triangle> tab){
		ArrayList<Triangle> res = new ArrayList<>();
		for (Triangle i : tab){
			if ( (this.debut.memeEndroit(i.getPoint1()) && (this.fin.memeEndroit(i.getPoint2()) || this.fin.memeEndroit(i.getPoint3() ) ) )  ||
			(this.debut.memeEndroit(i.getPoint2()) && (this.fin.memeEndroit(i.getPoint1()) || this.fin.memeEndroit(i.getPoint3() ) ) ) ||
			(this.debut.memeEndroit(i.getPoint3()) && (this.fin.memeEndroit(i.getPoint2()) || this.fin.memeEndroit(i.getPoint1() ) ) )){
				
				res.add(i);
			}
		}
		return res;
	}
	public Droite perpendiculaire() {
		int milieuX = (int) (this.debut.getX() + this.fin.getX()) / 2;
		int milieuY = (int) (this.debut.getY() + this.fin.getY()) / 2;
	
		float pentePerpendiculaire = -1 / this.getA();
	
		int chercheX;
		int chercheY;
		if (!Float.isFinite(pentePerpendiculaire)) {
			chercheX = milieuX;
			chercheY = milieuY + 1024;
			return new Droite(new Point(milieuX, milieuY - 1024), new Point(chercheX, chercheY));
		} else {
			chercheX = milieuX + 1024;
			chercheY = milieuY + (int) (pentePerpendiculaire * (chercheX - milieuX));
			int deplacementY = chercheY - milieuY;
			int deplacementX = chercheX - milieuX;
			return new Droite(new Point(milieuX - 5 * deplacementX, milieuY - 5 * deplacementY), new Point(chercheX + 5 * deplacementX, chercheY + 5 * deplacementY));
		}
	}

	public Point intersectionDroitePoint(Droite d){

		int x = (int) ((d.getB() - this.getB()) / (this.getA() - d.getA()));
		int y = (int) ( this.getA() * x + this.getB());

		return new Point(x, y);
	}

	public boolean intersectionDroiteDroite(Droite d) {
		// Coordinates of this segment
		float x1 = this.getDebut().getX();
		float y1 = this.getDebut().getY();
		float x2 = this.getFin().getX();
		float y2 = this.getFin().getY();
	
		// Coordinates of segment d
		float x3 = d.getDebut().getX();
		float y3 = d.getDebut().getY();
		float x4 = d.getFin().getX();
		float y4 = d.getFin().getY();
	
		// Calculer les déterminants pour trouver le point d'intersection
		float denom = (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1);
	
		// Si denom est zéro, les droites sont parallèles
		if (denom == 0) {
			return false;
		}
	
		float ua = ((x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3)) / denom;
		float ub = ((x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3)) / denom;
	
		// Si ua et ub sont compris entre 0 et 1, les segments se coupent
		if (ua >= 0 && ua <= 1 && ub >= 0 && ub <= 1) {
			return true;
		} else {
			return false;
		}
	}	
	public boolean memeDroite(Droite d){
		return ( (this.getDebut().equals(d.getDebut()) && this.getFin().equals(d.getFin()) ) || (this.getDebut().equals(d.getFin()) && this.getFin().equals(d.getDebut())) );
	}
	 
	//si egal retourne faux
	public boolean estAuDessus(Point p) {
		if (p.getY() > this.getA() * p.getX() + this.getB()) {
			return true;
		}else {
			return false;
		}
	}
	public boolean estEnDessous(Point p) {
		return !(estAuDessus(p));
	}
}
