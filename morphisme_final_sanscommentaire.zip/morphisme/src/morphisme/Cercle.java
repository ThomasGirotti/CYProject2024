package morphisme;

public class Cercle {
    private Point centre;
    private float rayon;

    public Cercle(Point p , float r){
        this.centre = p;
        this.rayon = r;
    }
    public Point getCentre(){
        return this.centre ;
    }
    public float getRayon(){
        return this.rayon ;
    }
    // retourne vrai si sur le cercle
    public boolean contient(Point p){
        if (p.distance(this.centre) > this.rayon){
            return false;
        }else{
            return true;
        }
    }
}
