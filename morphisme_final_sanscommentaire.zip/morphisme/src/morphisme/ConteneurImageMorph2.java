package morphisme;

import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.CubicCurve;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class ConteneurImageMorph2 extends ConteneurImage {
    private int compteurPointsControl;
    private boolean isCompleted = false;

    public ConteneurImageMorph2(Stage primaryStage, int screenX, int screenY, ImageImportListener listener) {
        super(primaryStage, screenX, screenY, listener);
        this.compteurPointsControl = 0;
    }

    @Override
    protected void rollbackPoints(int removedPointNumber) {
        super.rollbackPoints(removedPointNumber);
        updateCurves();
    }

    @Override
    protected void removePointAndUpdate(PointView pointView, ArrayList<PointView> points, Pane overlayPane) {
        int index = points.indexOf(pointView);
        if (index > 0) {
            PointView control1 = points.get(index - 1);
            PointView control2 = points.get(index - 2);
            points.remove(control1);
            points.remove(control2);
            overlayPane.getChildren().remove(control1.getCircle());
            overlayPane.getChildren().remove(control1.getLabel());
            overlayPane.getChildren().remove(control2.getCircle());
            overlayPane.getChildren().remove(control2.getLabel());
            compteurPointsControl--;
        }
        points.remove(pointView);
        overlayPane.getChildren().remove(pointView.getCircle());
        overlayPane.getChildren().remove(pointView.getLabel());
        updateCurves();
    }

    protected void updateCurves() {
        getOverlayPane().getChildren().removeIf(node -> node instanceof CubicCurve);
        getLines().clear();
        if (getPoints().size() < 4) {
            return;
        }
        for (int i = 0; i < getPoints().size() - 1; i += 3) {
            if (i + 3 < getPoints().size()) {
                PointView start = getPoints().get(i);
                PointView control1 = getPoints().get(i + 1);
                PointView control2 = getPoints().get(i + 2);
                PointView end = getPoints().get(i + 3);
                addCurve(start, control1, control2, end);
            }
        }
    }

    @Override
    protected void handleMousePressed(MouseEvent event) {
        if (getPhoto().getImage() != null) {
            if (!(event.getTarget() instanceof Circle)) {
                if (!isCompleted) {
                    int xMouse = (int) event.getX();
                    int yMouse = (int) event.getY();
                    int setx = (int) (xMouse / getPhoto().getImageView().getFitWidth() * getImageBrute().getWidth());
                    int sety = (int) (yMouse / getPhoto().getImageView().getFitHeight() * getImageBrute().getHeight());
                    PointView pv = new PointView(xMouse, yMouse, "P" + getCompteurPoints());
                    pv.getPoint().setX(setx);
                    pv.getPoint().setY(sety);
                    pv.getCircle().setOnMouseEntered(e -> pv.getCircle().setRadius(10d));
                    pv.getCircle().setOnMouseExited(e -> pv.getCircle().setRadius(5d));
                    Label nameLabel = new Label(pv.getName());
                    nameLabel.setTextFill(Color.BLACK);
                    nameLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
                    pv.setLabel(nameLabel);
                    getPoints().add(pv);
                    getOverlayPane().getChildren().add(pv.getCircle());
                    nameLabel.setLayoutX(pv.getCircle().getCenterX() + pv.getCircle().getTranslateX() + pv.getCircle().getRadius() + 5);
                    nameLabel.setLayoutY(pv.getCircle().getCenterY() + pv.getCircle().getTranslateY() - 10);
                    getOverlayPane().getChildren().add(nameLabel);
                    if (getPoints().size() > 1 && (getPoints().size() - 2) % 3 == 0) {
                        addControlPoints(pv);
                    }
                    setCompteurPoints(getCompteurPoints() + 1);
                    updateCurves();
                } else {
                    String warningText = "La forme est déjà fermée.\n Pour en créer une nouvelle, veuillez cliquer sur le bouton 'Réinitialiser Points'";
                    Label label = new Label(warningText);
                    label.setWrapText(true);
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.getDialogPane().setContent(label);
                    alert.showAndWait();
                }
            } else {
                Circle circlePressed = (Circle) event.getTarget();
                PointView pointViewPressed = getPoints().stream()
                        .filter(pv -> pv.getCircle().equals(circlePressed))
                        .findFirst().orElse(null);
                if (pointViewPressed != null) {
                    circlePressed.setRadius(10d);
                    pointViewPressed.setOrgSceneX((int) event.getSceneX());
                    pointViewPressed.setOrgSceneY((int) event.getSceneY());
                    pointViewPressed.setOrgTranslateX((int) circlePressed.getTranslateX());
                    pointViewPressed.setOrgTranslateY((int) circlePressed.getTranslateY());
                }
            }
        } else {
            fileSelect(getPhoto());
        }
    }

    @Override
    protected void handleMouseDragged(MouseEvent event) {
        super.handleMouseDragged(event);
        updateCurves();
    }

    private void addCurve(PointView start, PointView control1, PointView control2, PointView end) {
        CubicCurve curve = new CubicCurve();
        curve.setStartX(start.getCircle().getCenterX() + start.getCircle().getTranslateX());
        curve.setStartY(start.getCircle().getCenterY() + start.getCircle().getTranslateY());
        curve.setControlX1(control1.getCircle().getCenterX() + control1.getCircle().getTranslateX());
        curve.setControlY1(control1.getCircle().getCenterY() + control1.getCircle().getTranslateY());
        curve.setControlX2(control2.getCircle().getCenterX() + control2.getCircle().getTranslateX());
        curve.setControlY2(control2.getCircle().getCenterY() + control2.getCircle().getTranslateY());
        curve.setEndX(end.getCircle().getCenterX() + end.getCircle().getTranslateX());
        curve.setEndY(end.getCircle().getCenterY() + end.getCircle().getTranslateY());
        curve.setFill(null);
        curve.setStroke(Color.RED);
        curve.setMouseTransparent(true);
        getLines().add(new LineView(start, end, curve));
        getOverlayPane().getChildren().add(curve);
    }

    private void addControlPoints(PointView lastAddedPoint) {
        PointView control1 = createControlPoint(lastAddedPoint, 30, 30);
        PointView control2 = createControlPoint(lastAddedPoint, -30, -30);
        getPoints().add(getPoints().size() - 1, control1);
        getPoints().add(getPoints().size() - 1, control2);
        compteurPointsControl--;
        getOverlayPane().getChildren().add(control1.getCircle());
        getOverlayPane().getChildren().add(control2.getCircle());
        getOverlayPane().getChildren().add(control1.getLabel());
        getOverlayPane().getChildren().add(control2.getLabel());
    }

    private PointView createControlPoint(PointView referencePoint, int offsetX, int offsetY) {
        int x = (int) referencePoint.getCircle().getCenterX() + offsetX;
        int y = (int) referencePoint.getCircle().getCenterY() + offsetY;
        PointView controlPoint = new PointView(x, y, "C" + compteurPointsControl);
        controlPoint.getPoint().setX((int) (x / getPhoto().getImageView().getFitWidth() * getImageBrute().getWidth()));
        controlPoint.getPoint().setY((int) (y / getPhoto().getImageView().getFitHeight() * getImageBrute().getHeight()));
        controlPoint.getCircle().setOnMouseEntered(e -> controlPoint.getCircle().setRadius(10d));
        controlPoint.getCircle().setOnMouseExited(e -> controlPoint.getCircle().setRadius(5d));
        Label nameLabel = new Label(controlPoint.getName());
        nameLabel.setTextFill(Color.BLACK);
        nameLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        controlPoint.setLabel(nameLabel);
        nameLabel.setLayoutX(controlPoint.getCircle().getCenterX() + controlPoint.getCircle().getTranslateX() + controlPoint.getCircle().getRadius() + 5);
        nameLabel.setLayoutY(controlPoint.getCircle().getCenterY() + controlPoint.getCircle().getTranslateY() - 10);
        compteurPointsControl++;
        return controlPoint;
    }

    protected void addLastLine() {
        if (getPoints().size() > 3 && !isCompleted) {
            PointView pv = getPoints().get(0);
            getPoints().add(pv);
            if (getPoints().size() > 1 && (getPoints().size() - 2) % 3 == 0) {
                PointView control1 = createControlPoint(pv, 30, 30);
                PointView control2 = createControlPoint(pv, -30, -30);
                getPoints().add(getPoints().size() - 1, control1);
                getPoints().add(getPoints().size() - 1, control2);
                compteurPointsControl--;
                getOverlayPane().getChildren().add(control1.getCircle());
                getOverlayPane().getChildren().add(control2.getCircle());
                getOverlayPane().getChildren().add(control1.getLabel());
                getOverlayPane().getChildren().add(control2.getLabel());
            }
            setCompteurPoints(getCompteurPoints() + 1);
            updateCurves();
            isCompleted = true;
        } else {
            String warningText = "La forme est déjà fermée.\n Pour en créer une nouvelle, veuillez cliquer sur le bouton 'Réinitialiser Points'";
            Label label = new Label(warningText);
            label.setWrapText(true);
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.getDialogPane().setContent(label);
            alert.showAndWait();
        }
    }

    public int getCompteurPointsControl() {
        return compteurPointsControl;
    }

    public void setCompteurPointsControl(int compteurPointsControl) {
        this.compteurPointsControl = compteurPointsControl;
    }

    public void setIsComplete(boolean isCompleted) {
        this.isCompleted = isCompleted;
    }
}